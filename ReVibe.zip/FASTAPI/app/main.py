from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from models.models import preprocess_text, preprocess_face, predict_text, predict_face, b64encode_face
import time

app = FastAPI()

class Inputs(BaseModel):
    text: str
    face: str

class Outputs(BaseModel):
    message: str
    in_text: str
    timestamp: float
    text_preds: dict
    img_preds: dict
    prep_text: str
    prep_img: str

@app.get("/")
def home():
    return {"status": "OK"}

@app.post("/predict", response_model=Outputs)
def predict(payload: Inputs, qi = Header(None)):
    if qi != "changethis":
        raise HTTPException(status_code=401, detail="Unauthorized")
    try:
        preprocessed_text = preprocess_text(payload.text)
        preprocessed_face = preprocess_face(payload.face)
        b64_face = b64encode_face(preprocessed_face)

        predictions_text = predict_text(preprocessed_text)
        predictions_face = predict_face(preprocessed_face)
        timestamp = time.time()
        return {
            "message": "OK: complete",
            "in_text": payload.text,
            "timestamp": timestamp,
            "text_preds": predictions_text,
            "img_preds": predictions_face,
            'prep_text': preprocessed_text,
            'prep_img': b64_face
        }
    except Exception as error:
        print(error)
        return {
            "message": "Error",
            "in_text": "Error",
            "timestamp": 34404.34404,
            "text_preds": {},
            "img_preds": {},
            'prep_text': "Error",
            'prep_img': "Error"
        }


