import pickle
import numpy as np
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from tensorflow.keras.preprocessing.sequence import pad_sequences
import re
from pathlib import Path
from tensorflow.keras.models import load_model
import cv2
import base64

nltk.download('stopwords')
nltk.download('punkt_tab')
nltk.download('wordnet')
faceDetector = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
wn = nltk.WordNetLemmatizer()
stop_words = set(stopwords.words('english'))

# load dependencies
BASE_DIR = Path(__file__).resolve(strict=True).parent
# FER
fer_model = load_model(f"{BASE_DIR}/localTrainedFin.keras")

# TER
with open(f"{BASE_DIR.as_posix()}/tokenizer.pickle", "rb") as f:
    tokenizer = pickle.load(f)

with open(f"{BASE_DIR.as_posix()}/feature_extractor.pickle", "rb") as f:
    feature_extractor = pickle.load(f)

with open(f"{BASE_DIR.as_posix()}/model.pkl", "rb") as f:
    ter_model = pickle.load(f)


# helper functions

def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'http\S+', '', text)
    text = re.sub(r'[^\w\s]', '', text)
    text = word_tokenize(text)
    text = [word for word in text if word not in stop_words]
    text = [wn.lemmatize(word) for word in text]
    return ' '.join(text)

def predict_text(ptext):
    print('predicting text')
    text = tokenizer.texts_to_sequences([ptext])
    text = pad_sequences(text, maxlen = 100, padding='post')
    features = feature_extractor.predict(text)
    predSVM = ter_model.predict_proba(features) #returns array of probabilities
    labelDict = {'sad':str(predSVM[0][0]), 'happy':str(predSVM[0][1]), 'angry':str(predSVM[0][2]), 'fear':str(predSVM[0][3]), 'surprise':str(predSVM[0][4])}
    print('text prediction finished')
    return labelDict

def preprocess_face(imstr):
    # load image and grayscale
    imarr = np.frombuffer(base64.b64decode(imstr), np.uint8)
    img = cv2.imdecode(imarr,0)
    # find face
    face = faceDetector.detectMultiScale(img, scaleFactor=1.3, minNeighbors=5, minSize=(40,40))
    try:
        for (x, y, w, h) in face:
            cropFace = img[y:y + h, x: x+w]
        forPredicting = cv2.resize(cropFace, (48,48))
        return forPredicting
    except Exception as error:
        print(error)

def predict_face(img):
    print('predicting face')
    img = np.expand_dims(img, axis = 0)
    img = img.reshape(1,48,48,1)
    result = fer_model.predict(img)
    result = list(result[0])
    dictRes = {'angry': str(result[0]), 'fear':str(result[1]), 'happy':str(result[2]), 'sad':str(result[3]), 'surprise':str(result[4])}
    print('face prediction finished')
    return dictRes

def b64encode_face(pimg):
    strImg = cv2.imencode('.jpg', pimg)[1].tobytes()
    strImg = base64.b64encode(strImg)
    decoded = strImg.decode('utf-8')
    return decoded