-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2025 at 04:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `revibedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `pwdreset`
--

CREATE TABLE `pwdreset` (
  `pwdResetId` int(11) NOT NULL,
  `pwdResetEmail` varchar(255) NOT NULL,
  `pwdResetSelector` text NOT NULL,
  `pwdResetToken` longtext NOT NULL,
  `pwdResetExpires` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `recommendations`
--

CREATE TABLE `recommendations` (
  `id` int(11) NOT NULL,
  `users_id` int(11) DEFAULT NULL,
  `created_at` int(32) UNSIGNED NOT NULL,
  `reco_type` varchar(16) NOT NULL,
  `subtype` varchar(64) NOT NULL,
  `is_correct_prediction` varchar(16) NOT NULL DEFAULT 'na',
  `replacement_to` varchar(32) NOT NULL DEFAULT 'none',
  `input_text` varchar(255) DEFAULT NULL,
  `input_image_loc` varchar(100) DEFAULT NULL,
  `recos_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`recos_json`)),
  `pred_info_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`pred_info_json`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `userpreferences`
--

CREATE TABLE `userpreferences` (
  `id` int(11) NOT NULL,
  `users_id` int(11) DEFAULT NULL,
  `pref_status` varchar(24) NOT NULL DEFAULT 'default',
  `genre1` varchar(32) NOT NULL DEFAULT 'acoustic',
  `genre2` varchar(32) NOT NULL DEFAULT 'afrobeat',
  `fav_artist` varchar(255) NOT NULL DEFAULT '0a4r2EnsevvHCukoJ1xFwJ+juan karlos',
  `fav_track` varchar(255) NOT NULL DEFAULT '5f9808hpiCpuNyqqdXmpF2+Buwan+juan karlos',
  `when_happy` varchar(24) NOT NULL DEFAULT 'happy',
  `when_sad` varchar(24) NOT NULL DEFAULT 'happy',
  `when_angry` varchar(24) NOT NULL DEFAULT 'happy',
  `when_surprise` varchar(24) NOT NULL DEFAULT 'happy',
  `when_fear` varchar(24) NOT NULL DEFAULT 'happy',
  `when_sunny` varchar(24) NOT NULL DEFAULT 'happy',
  `when_rainy` varchar(24) NOT NULL DEFAULT 'happy',
  `when_hot` varchar(24) NOT NULL DEFAULT 'happy',
  `when_cold` varchar(24) NOT NULL DEFAULT 'happy'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `age` int(3) UNSIGNED NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `user_type` varchar(32) NOT NULL DEFAULT 'icf pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `websetting`
--

CREATE TABLE `websetting` (
  `setting_id` int(3) UNSIGNED NOT NULL,
  `setting_name` varchar(255) NOT NULL,
  `setting_value1` varchar(255) NOT NULL,
  `setting_value2` varchar(32) DEFAULT NULL,
  `expires_at` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `websetting`
--

INSERT INTO `websetting` (`setting_id`, `setting_name`, `setting_value1`, `setting_value2`, `expires_at`) VALUES
(1, 'spotify_token', 'token', 'Bearer', 100000);

-- --------------------------------------------------------

--
-- Table structure for table `ytlinks`
--

CREATE TABLE `ytlinks` (
  `id` int(11) NOT NULL,
  `tid` varchar(64) NOT NULL,
  `ytid` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pwdreset`
--
ALTER TABLE `pwdreset`
  ADD PRIMARY KEY (`pwdResetId`);

--
-- Indexes for table `recommendations`
--
ALTER TABLE `recommendations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_id` (`users_id`);

--
-- Indexes for table `userpreferences`
--
ALTER TABLE `userpreferences`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_id` (`users_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `websetting`
--
ALTER TABLE `websetting`
  ADD PRIMARY KEY (`setting_id`);

--
-- Indexes for table `ytlinks`
--
ALTER TABLE `ytlinks`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pwdreset`
--
ALTER TABLE `pwdreset`
  MODIFY `pwdResetId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recommendations`
--
ALTER TABLE `recommendations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `userpreferences`
--
ALTER TABLE `userpreferences`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `websetting`
--
ALTER TABLE `websetting`
  MODIFY `setting_id` int(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ytlinks`
--
ALTER TABLE `ytlinks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `recommendations`
--
ALTER TABLE `recommendations`
  ADD CONSTRAINT `recommendations_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `userpreferences`
--
ALTER TABLE `userpreferences`
  ADD CONSTRAINT `userpreferences_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
