|----------------------UPDATE----------------------|
> Spotify has ended support for the 'recommendations' endpoint which is a core requirement for this web app. This means that while the web app can create and save your preferences, it can't recommend songs anymore. It is suggested to look for alternatives for this if any, should you continue to use this web app.

For more information, see here:
https://developer.spotify.com/blog/2024-11-27-changes-to-the-web-api

|--------------------------------------------|

Before Starting:

for Youtube Keys
> change 'qi' to key value from google cloud key which can access the youtube api. place value in:
   - revibe_final/includes/youtube_contr.inc.php | line 8

For Spotify keys
> change 'client_id' and 'client_secret' to your values in
   - revibe_final/includes/spotify_session.inc.php | lines 7 and 8
> these are given in the spotify developer dashboard.

For Model
----------simple key check----------
> change 'qi' variable in:
   - FASTAPI/app/main.py | line 27
  and 'kay' variable with same value as 'qi' in:
   - revibe_final/includes/predict_contr.inc.php | line 7


|--------------------------------------------|

Instructions for localhosting

----------Web App----------


 > have XAMPP installed and place contents of 'revibe_final' folder in 'htdocs'
 > in phpMyAdmin, create a database named 'revibedb'
 > with 'revibedb' open, import 'revibedb.sql' to populate the database.


----------Python Model----------

 > to locally run the model, VSCode can be used from anaconda navigator, environment python version is 3.10.12 and follows 
the 'requirements.txt' in:
   - FASTAPI/requirements.txt
 > to run, type in terminal 'uvicorn main:app' while in 'FASTAPI/app' directory
> change 'url' depending on uvicorn run in:
   - revibe_final/includes/predict_contr.inc.php | line 8

|--------------------------------------------|

