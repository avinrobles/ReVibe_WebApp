<?php
require_once 'includes/config_session.inc.php';
require_once 'includes/signup_view.inc.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up | ReVibe</title>
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/main.css?v=1.0.1">
</head>
<body>
    <div class="row w100">
        <div class="col-5 svg-container">
            <img src="webimages/REVIBE.svg">
        </div>
        <div class="col-7">
            <div class="container">
                <form id="signupForm" class="form" action="includes/signup.inc.php" method="POST">
                    <img src="webimages/REVIBE.svg" class="mobile_logo">
                    <h2>Join the Community</h2>
                    <?php
                    signup();
                    ?>

                    <p class='increase-space'>By signing up, I have read, understood and agree to the <a href="forms/EULA.pdf" class="ltext" target="_blank" rel="noopener noreferrer">EULA <i class='bx bx-link-external'></i></a>, <a href="forms/PrivacyPolicy.pdf" class="ltext" target="_blank" rel="noopener noreferrer">Privacy Policy <i class='bx bx-link-external'></i></a>, and the <a href="forms/TermsConditions.pdf" class="ltext" target="_blank" rel="noopener noreferrer">Terms and Conditions <i class='bx bx-link-external'></i></a> of ReVibe.
                    
                    </p><br>
                    <button type="submit" class="btn-signup" id='submit-btn'>Sign Up</button>
                </form>

                <?php
                    check_signup_errors();
                ?>

                <p>Already have an account? <a href="index.php">Login</a></p>
            </div>
            <p>*Due to study requirements, only ages 18 and above are allowed to register and use this web application.</p>
            <br>
        </div>
    </div>
    <script src="js/script.js"></script>
</body>
</html>