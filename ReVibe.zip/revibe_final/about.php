<?php
require_once 'includes/config_session.inc.php';

if (!isset($_SESSION["user_id"])) {
    header('Location: index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About ReVibe | ReVibe</title>
    <link rel="stylesheet" href="css/reset.css">
    <?php require 'parts/css.parts.php';?>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>
<body class="home-gradient">
    <div class="grid-main">
        <div class="grid-container header">
            <div class="title-header"><p class="bold">About ReVibe</p>
            </div>
        </div>
        <div class="grid-container main-content main">
            <div class="grid-box-static "> 
                <!-- custom-size -->
                <div class="logo-header abt-img"></div>
                <br>

                <bold class='header-text'>What is ReVibe?</bold><br> <br>

                <p class='justify-text'><bold>REVIBE</bold> is an affective music recommendation system that utilizes both <bold>Facial & Text Emotion Recognitions</bold> to suggest personalized songs based on the predicted emotion of the user.
                The goal of the system is to promote wellbeing and mood of the user by recommendation of personalized tracks that may or may not pique the user's interest. Revibe can predict five emotion states; Happy, Sad, Angry, Fear, and Surprise. <br> <br>
                The system came to fruition thanks to Nico, Matthew and Ma2.
                </p>
            </div>
        </div>
    </div>
    <?php require 'parts/sidebar.parts.php';?>
</body>
<script>
    let burger = document.querySelector("#burger");
    let sidebar = document.querySelector('.sidebar');
    burger.onclick = function() {
        sidebar.classList.toggle('active');
    }

</script>
</html>