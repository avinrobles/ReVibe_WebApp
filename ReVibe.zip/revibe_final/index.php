<?php
    require_once 'includes/config_session.inc.php';
    require_once 'includes/login_view.inc.php';

    if (isset($_SESSION["user_id"])) {
        header('Location: home.php');
    }
    
    $maintenance = 0;
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | ReVibe</title>
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/main.css">
    
</head>
<body>
    <div class="row vh100">
        <div class="col-6 svg-container">
            <img src="webimages/REVIBE.svg">
        </div>
        <div class="col-6">
            <div class="container">
                <?php 
                if (!$maintenance) {
                    echo'
                    <form id="loginForm" class="form" action="includes/login.inc.php" method="POST">
                    <img src="webimages/REVIBE.svg" class="mobile_logo">
                    <h2>Welcome Back</h2>


                    <div class="form-control">
                        <input type="text" id="username" name="username" placeholder=" " required maxlength="32">
                        <label for="username">Username</label>
                    </div>
                    <div class="form-control">
                        <input type="password" id="password" name="pwd" placeholder=" " required>
                        <label for="password">Password</label>
                    </div>
                    <button class="btn-login">Login</button>
                </form>
                    ';
                } else {
                    echo '
                    <h2>
                    The Web App is currently unavailable, sorry for the inconvenience.</h2> 
                    
                    ';
                }
                ?>
                

                <?php
                check_login_errors();
                check_pwdreset_status();
                ?>

                <p>Don't have an account? <a href="signup.php">Sign up</a></p>
            </div>
           <!-- <div class="container">
            <p>Forgot Password? <a href="#">Click Here</a></p>
           </div> -->
        </div>
    </div>
    <!--<script src="js/script.js"></script>-->
</body>
</html>
