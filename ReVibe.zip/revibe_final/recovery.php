<?php
require_once 'includes/config_session.inc.php';
require_once 'includes/recovery_view.inc.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recovery | ReVibe</title>
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/main.css">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <script>
        function enableSubmitBtn() {
            document.getElementById("submit-btn").disabled = false;
        }
    </script>
</head>
<body>
    <div class="row">
        <div class="col-6 svg-container">
            <img src="webimages/REVIBE.svg">
        </div>
        <div class="col-6">
            <div class="container">
                <form id="recoveryForm" class="form" action="includes/recovery.inc.php" method="POST">
                    <img src="webimages/REVIBE.svg" class="mobile_logo">
                    <h2>Password Reset</h2>
                    <div class="form-control">
                        <input type="text" id="email" name='email' placeholder="" required> 
                        <label for="email">Email</label>
                    </div><br>
                    <div class="g-recaptcha" data-sitekey="6LfTpYUqAAAAADIipNp4F-P8FzIcW9dFbtpWHX_v" data-callback="enableSubmitBtn" style="transform:scale(0.77);transform-origin:0 0"></div><br>

                    <button type="submit" class="btn-signup" id='submit-btn' disabled='disabled'>Reset Password</button>
                </form>

                <?php
                    check_recovery_errors();
                    if(isset($_GET['reset'])) {
                        if ($_GET['reset'] == "success") {
                            echo '<p class="success">Reset request successful, please check your email.</p>';
                        }
                    }
                ?>

                <p>Click <a href="index.php">here</a> to return to the login page.</p>
            </div>
        </div>
    </div>
    <script src="js/script.js"></script>
</body>
</html>