<?php
require_once 'includes/config_session.inc.php';
require_once 'includes/home_view.inc.php';

if (!isset($_SESSION["user_id"])) {
    header('Location: index.php');
}

// checks if user has submitted ICF
//require_once 'includes/check_user_status.inc.php';
if ($_SESSION["user_status"] == 'icf pending') {
    // $pdo = null;
    // $stmt = null;
    // header('Location: agreement_forms.php?nu=y');
    // die();
}


// checks if user has personalized preferences
require_once 'includes/check_status.inc.php';
if ($_SESSION["user_pref_status"] == 'default') {
    // $pdo = null;
    // $stmt = null;
    // header('Location: preference.php');
    // die();
}
$pdo = null;
$stmt = null;

$now = time();
$birth = strtotime($_SESSION['birthdate']);
$timePassed = $now - $birth;
//now notifies after 1 day 86400
if (($now-$birth) > 86400 && $_SESSION['user_status'] == 'survey_pending' && !isset($_SESSION['notified'])) {
    $_SESSION['notified'] = 1;
    header('Location: survey.php');
    die();
}

//var_dump($_SESSION);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | ReVibe</title>
    <link rel="stylesheet" href="css/reset.css">
    <?php require 'parts/css.parts.php';?>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>
<body class="home-gradient">
    <div class="grid-main home-containers">
        <div class="grid-container header">
            <div class="title-header"><p class="bold">Welcome Back, <?php  output_username() ?>!</p>
            </div>
        </div>
        <div class="grid-container main-content left">
            <div class="grid-box dual pointer">
                <div class='default'><i class='bx bxs-music bigger' ></i></div>
                <span class="bold big default">New Music Recommendation</span>
                <div class="dual_active scroll-on-overflow">
                    <div class="col1">
                        <a href="reco_emotion.php"><div class="grid-box-inv da_btn" id='emotion'>
                        <i class='bx bxs-smile big'></i>
                            <span class="nav-item big bold">Emotion</span>
                        </div></a>
                    </div>

                    <div class="col2">
                        <a href="reco_weather.php"><div class="grid-box-inv da_btn" id='weatherb'>
                        <i class='bx bxs-sun big'></i>
                            <span class="nav-item big bold">Environment Weather</span>
                        </div></a>
                    </div>

                    <div class="row2_1">
                    <button type='submit' value='Submit' form='relaxb' class='fill no-padding'>
                        <div class="grid-box-inv da_btn" id='r-and-r'>
                            <i class='bx bxs-spa big'></i>
                            <span class="nav-item big bold">Stress Relief</span>
                        </div>
                    </button>
                        <form action="includes/recommend.inc.php" method="post" id='relaxb'><input type="hidden" name='type' value='relax' id='type'></form>
                    </div>

                    <div class="row2_2">
                        <button type='submit' value='Submit' form='sleepb' class='fill no-padding'>
                            <div class="grid-box-inv da_btn" id='sleep'>
                                <i class='bx bxs-bed big'></i>
                                <span class="nav-item big bold">Sleep</span>
                            </div>
                        </button>
                        <form action="includes/recommend.inc.php" method="post" id='sleepb'><input type="hidden" name='type' value='sleep' id='type'></form>
                    </div>
                </div>
            </div>
        </div>
        <div class="grid-container main-content top-half">
            <a href="history.php">
            <div class="grid-box">
                <div><i class='bx bx-history bigger' ></i></div>
                <span class="bold big">Recommendation History</span>
            </div>
            </a>
        </div>
        <div class="grid-container main-content bot-half">
            <a href="preference.php">
            <div class="grid-box">
                <div><i class='bx bx-slider bigger' ></i></div>
                <span class="bold big">Music Preferences</span>
            </div>
            </a>
        </div>
    </div>
    <?php require 'parts/sidebar.parts.php';?>
</body>
<script>
    let burger = document.querySelector("#burger");
    let sidebar = document.querySelector('.sidebar');
    burger.onclick = function() {
        sidebar.classList.toggle('active');
    }

    let mscReco = document.querySelector('.dual');
    mscReco.onclick = function() {
        mscReco.classList.toggle('active');
    }
</script>
</html>