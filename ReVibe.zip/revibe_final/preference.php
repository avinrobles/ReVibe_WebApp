<?php
require_once 'includes/config_session.inc.php';

if (!isset($_SESSION["user_id"])) {
    header('Location: index.php');
}

require_once 'includes/show_preferences.inc.php';

$genres = [ "acoustic", "afrobeat", "alt-rock", "alternative", "ambient", "anime", "black-metal", "bluegrass", "blues", "bossanova", "brazil", "breakbeat", "british", "cantopop", "chicago-house", "children", "chill", "classical", "club", "comedy", "country", "dance", "dancehall", "death-metal", "deep-house", "detroit-techno", "disco", "disney", "drum-and-bass", "dub", "dubstep", "edm", "electro", "electronic", "emo", "folk", "forro", "french", "funk", "garage", "german", "gospel", "goth", "grindcore", "groove", "grunge", "guitar", "happy", "hard-rock", "hardcore", "hardstyle", "heavy-metal", "hip-hop", "holidays", "honky-tonk", "house", "idm", "indian", "indie", "indie-pop", "industrial", "iranian", "j-dance", "j-idol", "j-pop", "j-rock", "jazz", "k-pop", "kids", "latin", "latino", "malay", "mandopop", "metal", "metal-misc", "metalcore", "minimal-techno", "movies", "mpb", "new-age", "new-release", "opera", "pagode", "party", "philippines-opm", "piano", "pop", "pop-film", "post-dubstep", "power-pop", "progressive-house", "psych-rock", "punk", "punk-rock", "r-n-b", "rainy-day", "reggae", "reggaeton", "road-trip", "rock", "rock-n-roll", "rockabilly", "romance", "sad", "salsa", "samba", "sertanejo", "show-tunes", "singer-songwriter", "ska", "sleep", "songwriter", "soul", "soundtracks", "spanish", "study", "summer", "swedish", "synth-pop", "tango", "techno", "trance", "trip-hop", "turkish", "work-out", "world-music" ];

$emotion_vals = [
    ['happy', 'Happy'],
    ['pleased', 'Pleased'],
    ['relaxed', 'Relaxed'],
    ['peaceful', 'Peaceful'],
    ['excited', 'Excited'],
    ['calm', 'Calm'],
    ['sleepy', 'Sleepy'],
    ['angry', 'Angry'],
    ['nervous', 'Nervous'],
    ['bored', 'Bored'],
    ['sad', 'Sad'],
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preferences | ReVibe</title>
    <link rel="stylesheet" href="css/reset.css">
    <?php require 'parts/css.parts.php';?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script>
        $(document).ready(function () {

            $("#track-search").click(function() {
            track = $('#track').val();
            $.get("includes/search.inc.php", {
                query: track,
                type: 'track'
            }, function(data, status) {
                $(".track-results").html(data,status);
            });
            });

            $("#artist-search").click(function() {
            track = $('#artist').val();
            $.get("includes/search.inc.php", {
                query: track,
                type: 'artist'
            }, function(data, status) {
                $(".artist-results").html(data,status);
            });
            });
            $(window).keydown(function(event){
            if(event.key == 'Enter') {
                event.preventDefault();
                return false;
                }
            });
            $('#prefs').submit(function() {
                event.preventDefault();
                uid = <?php  echo $_SESSION["user_id"]; ?>;
                genre1 = $('#genre1').val();
                genre2 = $('#genre2').val();
                favtrack = $('#favtrack').val();
                favartist = $('#favartist').val();
                happy = $('#happy').val();
                sad = $('#sad').val();
                angry = $('#angry').val();
                surprise = $('#surprise').val();
                fear = $('#fear').val();
                sunny = $('#sunny').val();
                rainy = $('#rainy').val();
                hot = $('#hot').val();
                cold = $('#cold').val();
                submit = $('#submit').val();
                $('.status').load('includes/save_preference.inc.php', {
                    uid: uid,
                    genre1: genre1,
                    genre2: genre2,
                    favtrack: favtrack,
                    favartist: favartist,
                    happy: happy,
                    sad: sad,
                    angry: angry,
                    surprise: surprise,
                    fear: fear,
                    sunny: sunny,
                    rainy: rainy,
                    hot: hot,
                    cold: cold,
                    submit: submit
                })
            });
        });
    </script>

</head>
<body class="home-gradient">
    <div class="grid-main pref">
        <div class="grid-container header">
            <div class="title-header"><p class="bold">Music Preferences</p>
            </div>
        </div>
        <div class="grid-container main-content main">
            <div class="grid-box-static">
                <form action="includes/save_preference.inc.php" class="form" name="main" method="POST" id='prefs'>
                <div class="grid-internal">
                    <div class="int-left">
                        <h1>Personalize Your Music!</h1>
                        <p>Answer these questions personalize your music recommendations.</p><br>
                        <div>
                            <h3>What are your favorite music genres?</h3>
                            <label for="genre1">My two favorite music genres are: </label> <br class="vis-on-mob">
                            <select name="genre1" id="genre1" class="selection">
                            <?php
                            foreach ($genres as $genre) {
                                if ($genre == $prefs['genre1']) {
                                    echo "<option value='$genre' selected>$genre</option>";
                                } else {
                                    echo "<option value='$genre'>$genre</option>";
                                }
                            }
                            ?>
                            </select>
                            <br class="vis-on-mob"><label for="genre2">and</label><br class="vis-on-mob">

                            <select name="genre2" id="genre2" class="selection">
                            <?php
                            foreach ($genres as $genre) {
                                if ($genre == $prefs['genre2']) {
                                    echo "<option value='$genre' selected>$genre</option>";
                                } else {
                                    echo "<option value='$genre'>$genre</option>";
                                }
                            }
                            ?>
                            </select>
                        </div>
                        <br>
                        <h3>Search then select your favorite song!</h3>
                        <div class="form-control horizontal">
                            <input type="text" id="track" name="track" placeholder="" class="search-text">

                            <label for="track">Search Song</label>   
                            <button id='track-search' class="search-btn" type="button">Search</button>
                        </div>
                        <label for="favtrack">My Favorite Song: </label>
                        <div class="track-results custom-select">
                            <?php display_fav_track($prefs['fav_track']);?>
                        </div>

                        <h3>Search then select your favorite artist!</h3>
                        <div class="form-control horizontal">
                            <input type="text" id="artist" name="artist" placeholder="" class="search-text">
                            <label for="artist">Search Artist</label>   
                            <button id='artist-search' class="search-btn" type="button">Search</button>
                        </div>
                        <label for="favartist">My Favorite Artist: </label>
                        <div class="artist-results custom-select">
                            <?php display_fav_artist($prefs['fav_artist']);?>
                        </div>
                        <br>
                        <hr class="vis-on-mob">
                        <hr class="vis-on-mob">
                        <hr class="vis-on-mob">
                    </div>

                    <div class="int-right">
                        <br class="vis-on-mob">
                        <h1>Emotion Context</h1>
                        <p>Select the type of songs you want to get for your music recommendations based on how you feel.</p> <br>
                        <div>
                            <label for="happy">When I am <b>Happy</b>, I want</label>
                            <select name="happy" id="happy" class="selection">
                                <?php display_selected_value($emotion_vals, $prefs['when_happy']) ?>
                            </select>
                            <label for="happy"> Songs.</label>
                        </div> <br class='evis-on-mob'>

                        <div>
                            <label for="sad">When I am <b>Sad</b>, I want</label>
                            <select name="sad" id="sad" class="selection">
                            <?php display_selected_value($emotion_vals, $prefs['when_sad']) ?>
                            </select>
                            <label for="sad"> Songs.</label>
                        </div> <br class='evis-on-mob'>

                        <div>
                            <label for="angry">When I am <b>Angry</b>, I want</label>
                            <select name="angry" id="angry" class="selection">
                            <?php display_selected_value($emotion_vals, $prefs['when_angry']) ?>
                            </select>
                            <label for="angry"> Songs.</label>
                        </div> <br class='evis-on-mob'>

                        <div>
                            <label for="surprise">When I am <b>Surprised</b>, I want</label>
                            <select name="surprise" id="surprise" class="selection">
                            <?php display_selected_value($emotion_vals, $prefs['when_surprise']) ?>
                            </select>
                            <label for="surprise"> Songs.</label>
                        </div> <br class='evis-on-mob'>

                        <div>
                            <label for="fear">When I am <b>Afraid</b>, I want</label>
                            <select name="fear" id="fear" class="selection">
                            <?php display_selected_value($emotion_vals, $prefs['when_fear']) ?>
                            </select>
                            <label for="fear"> Songs.</label>
                        </div> <br>

                        <h1>Weather Context</h1>
                        <p>Select the type of songs you want to get for your music recommendations on weather conditions.</p> <br>
                        <div>
                            <label for="sunny">When it is <b>Sunny</b>, I want</label>
                            <select name="sunny" id="sunny" class="selection">
                                <?php display_selected_value($emotion_vals, $prefs['when_sunny']) ?>
                            </select>
                            <label for="sunny"> Songs.</label>
                        </div> <br class='evis-on-mob'>

                        <div>
                        <label for="rainy">When it is <b>Rainy</b>, I want</label>
                            <select name="rainy" id="rainy" class="selection">
                            <?php display_selected_value($emotion_vals, $prefs['when_rainy']) ?>
                            </select>
                            <label for="rainy"> Songs.</label>
                        </div> <br class='evis-on-mob'>

                        <div>
                            <label for="hot">When it is <b>Hot</b>, I want</label>
                            <select name="hot" id="hot" class="selection">
                            <?php display_selected_value($emotion_vals, $prefs['when_hot']) ?>
                            </select>
                            <label for="hot"> Songs.</label>
                        </div> <br class='evis-on-mob'>

                        <div>
                            <label for="cold">When it is <b>Cold</b>, I want</label>
                            <select name="cold" id="cold" class="selection">
                            <?php display_selected_value($emotion_vals, $prefs['when_cold']) ?>
                            </select>
                            <label for="cold"> Songs.</label>
                        </div> <br class='evis-on-mob'>


                    </div><br class="vis-on-mob">
                    <div class='int-bottom center'>
                        <div class="status"></div>
                        <button type='submit' class='btn-login' id='submit'>Update Preferences</button>
                        </form>
                    </div><br class="evis-on-mob">
                </div>
            </div>
        </div>

    </div>
    <?php require 'parts/sidebar.parts.php';?>
</body>
<script>
    let burger = document.querySelector("#burger");
    let sidebar = document.querySelector('.sidebar');
    burger.onclick = function() {
        sidebar.classList.toggle('active');
    }
</script>
</html>