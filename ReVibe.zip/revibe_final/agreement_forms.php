<?php
require_once 'includes/config_session.inc.php';
require_once 'includes/agreement_forms_view.inc.php';

if (!isset($_SESSION["user_id"])) {
    header('Location: index.php');
}

if (isset($_GET['nu'])) {
    $newUser = true;
} elseif (isset($_SESSION["user_status"]) && $_SESSION["user_status"] == 'icf pending') {
    $newUser = true;
} else $newUser = false;

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agreement Forms | ReVibe</title>
    <link rel="stylesheet" href="css/reset.css">
    <?php require 'parts/css.parts.php';?>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>
<body class="home-gradient">
    <div class="grid-main">
        <div class="grid-container header">
            <div class="title-header"><p class="bold">Agreement Forms</p>
            </div>
        </div>
        <div class="grid-container main-content main">
            <div class="grid-box-static  center"> 
                <?php 
                if ($newUser) {
                    // display_first_time_user($_SESSION["user_id"]);
                }
                ?>
                <p class="big bold">You can access the following forms if needed by clicking on them.</p><br>
                <h1>
                <ul class="links">
                    <li><a href="forms/EULA.pdf" class="ltext" target="_blank" rel="noopener noreferrer">EULA <i class='bx bx-link-external'></i></a></li>
                    <li><a href="forms/PrivacyPolicy.pdf" class="ltext" target="_blank" rel="noopener noreferrer">Privacy Policy <i class='bx bx-link-external'></i></a></li>
                    <li><a href="forms/TermsConditions.pdf" class="ltext" target="_blank" rel="noopener noreferrer">Terms and Conditions <i class='bx bx-link-external'></i></a></li>
                    <!--<li><a href="forms/ICF_EN.pdf" class="ltext" target="_blank" rel="noopener noreferrer">Informed Consent Form (ICF) - EN <i class='bx bx-link-external'></i></a></li>-->
                    <!--<li><a href="forms/ICF_TL.pdf" class="ltext" target="_blank" rel="noopener noreferrer">Informed Consent Form (ICF) - TL <i class='bx bx-link-external'></i></a></li>-->
                </ul> <br>
                </h1>
                <!-- <p class="big bold">Forgot to submit your ICF?</p><br>
                <h1> <ul class="links"> <li><a href="https://forms.gle/JaQHWfzcVD4Lnaf18" class="ltext" target="_blank" rel="noopener noreferrer">You can submit here! <i class="bx bx-link-external"></i></a></li> </ul> </h1> -->
            </div>
        </div>
    </div>
    <?php require 'parts/sidebar.parts.php';?>
</body>
<script>
    let burger = document.querySelector("#burger");
    let sidebar = document.querySelector('.sidebar');
    burger.onclick = function() {
        sidebar.classList.toggle('active');
    }
    
</script>
</html>