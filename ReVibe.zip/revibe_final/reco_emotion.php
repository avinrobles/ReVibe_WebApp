<?php
require_once 'includes/config_session.inc.php';

if (!isset($_SESSION["user_id"])) {
    header('Location: index.php');
}
if (!isset($_SESSION["user_pref_status"])) {
    require_once 'includes/check_status.inc.php';
} elseif ($_SESSION["user_pref_status"] == 'default') {
    header('Location: preference.php');
}

require_once 'includes/recommend_emo_view.inc.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recommendations-Emotion | Revibe</title>
    <link rel="stylesheet" href="css/reset.css">
    <?php require 'parts/css.parts.php';?>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>
<body class="emotion-gradient">
    <div class="grid-main">
        <div class="grid-container header">
            <div class="title-header"><p class="bold">Music Recommendation | Emotion Context</p>
            </div>
        </div>
        <div class="grid-container main-content main">
            <div class="grid-box-static">
            <form action="includes/recommend_emo.inc.php" method="POST" enctype="multipart/form-data" class='fill'>
                <div class="grid-internal">
                    <div class="int-left center-content">
                       <h1>Upload A Selfie!</h1>
                       <p class='bold'>When taking a selfie, please take note of the following:</p>
                       <ul class='guides'>
                           <li>ReVibe can only predict the following emotions:
                               <ul class='nested'>
                                   <li id='list-happy'>Happy</li>
                                   <li id='list-sad'>Sad</li>
                                   <li id='list-angry'>Angry</li>
                                   <li id='list-fear'>Fear</li>
                                   <li id='list-surprise'>Surprise</li>
                               </ul>
                           </li>
                           <li>Maximum file size is 3MB,</li>
                           <li>Be in a well lit room,</li>
                           <li>Face in front of the camera,</li>
                           <li>Have atleast 50% of the image be your face and</li>
                           <li>For a more accurate prediction, express how you feel through your face!</li>
                       </ul><br>
                        
                        <div class='wrapper'>
                        <button class="btn-login upload-btn">Upload File</button>
                       <input type="file" name="img" id="img" accept='.jpg,.jpeg,.png' required/>
                        </div>
                       <br><br>
                        <span id='file-status'>No File Chosen</span>
                       <br> <br>
                       <hr class="vis-on-mob">
                       <br>
                    </div>
                    <div class="int-right center-content">
                       <label for="text"><h1>Describe How You Feel!</h1></label>
                       <p class="bold">Within 250 characters and in english text, describe how you feel!</p> <br>
                       <textarea name="text" id="text" placeholder="Type Here" class='text-prompt' required><?php display_text(); ?></textarea>
                    </div>
                    <div class="int-bottom center"><br>
                    <div>
                    <?php check_errors(); ?>
                    </div>
                    <button type='submit' class='btn-login' id='submit'>Get New Songs</button>
                    <!-- <p class='big bold'>Due to limited resources, recommendations using emotions are unavailable, we apologize for the inconvenience.</p> -->
                    </div><br>

                </div>
            </div>
            <input type="hidden" id="currentuser" name="currentuser" value="<?php echo $_SESSION["user_id"]; ?>">
            <input type="hidden" id="type" name="type" value="emotion">
            </form>
        </div>
    </div>
    <?php require 'parts/sidebar.parts.php';?>
</body>
<script>
    let burger = document.querySelector("#burger");
    let sidebar = document.querySelector('.sidebar');
    burger.onclick = function() {
        sidebar.classList.toggle('active');
    }

    // adapted from Faddal Ibrahim, custom file upload
    // const img = document.getElementById('img');

    // const fileStatus = document.getElementById('file-status');

    // img.addEventListener('change', function(){
    //     fileStatus.textContent = this.files[0].name;
    // })
</script>
</html>