<div class="sidebar">
    <div class="top">
        <div class="sidebar-size">
        <div class="logo-header"></div>
        </div>
        <i class="bx bx-menu" id="burger"></i>
    </div>
    <ul>
        <li>
            <a href="home.php">
                <span class="nav-item">Home</span>
                <i class='bx bxs-home'></i>
            </a>
        </li>
        <li>
            <a href="howto.php">
                <span class="nav-item">How to Use ReVibe</span>
                <i class='bx bxs-help-circle'></i>
            </a>
        </li>
        <li>
            <a href="agreement_forms.php">
                <span class="nav-item">Agreement Forms</span>
                <i class='bx bxs-file' ></i>
            </a>
        </li>
        <!--<li>-->
        <!--    <a href="survey.php">-->
        <!--        <span class="nav-item">User Survey</span>-->
        <!--        <i class='bx bx-list-check'></i>-->
        <!--    </a>-->
        <!--</li>-->
        <li>
            <a href="about.php">
                <span class="nav-item">About ReVibe</span>
                <i class='bx bxs-group'></i>
            </a>
        </li>
    </ul>
    <div class="bottom">
        <form action="includes/logout.inc.php" class="form"> 
            <button class="logout">
                <span class="nav-item">Logout</span>
                <i class='bx bx-log-out'></i>
            </button>
        </form>
    </div>
</div>