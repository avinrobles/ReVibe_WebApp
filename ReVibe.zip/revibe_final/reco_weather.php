<?php
require_once 'includes/config_session.inc.php';

if (!isset($_SESSION["user_id"])) {
    header('Location: index.php');
}
if (!isset($_SESSION["user_pref_status"])) {
    require_once 'includes/check_status.inc.php';
} elseif ($_SESSION["user_pref_status"] == 'default') {
    header('Location: preference.php');
}
//var_dump($_SESSION);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recommendations-Weather|Revibe</title>
    <link rel="stylesheet" href="css/reset.css">
    <?php require 'parts/css.parts.php';?>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>
<body class="weather-gradient">
    <div class="grid-main">
        <div class="grid-container header">
            <div class="title-header"><p class="bold">Music Recommendation | Environment - Weather Context</p>
            </div>
        </div>
        <div class="grid-container main-content main">
            <div class="grid-box-static custom-size">
            <form action="includes/recommend.inc.php" method="POST" class='fill'>
                <div class="grid-internal">
                    <div class="int-whole-row center-content center">
                        <h1 class="big">Select the weather condition your recommendation will be based on!</h1><br>
                        <select name="weather" id="weather" class="selection big bold">
                            <option value='sunny' selected>Sunny</option>
                            <option value='rainy'>Rainy</option>
                            <option value='hot'>Hot</option>
                            <option value='cold'>Cold</option>
                        </select> <br>
                        <input type="hidden" id="currentuser" name="currentuser" value="<?php echo $_SESSION["user_id"]; ?>">
                        <input type="hidden" id="type" name="type" value="weather">
                        <br>
                        <hr class="vis-on-mob">
                    </div>
                    <div class="int-bottom center"><br>
                    <button type='submit' class='btn-login' id='submit'>Get New Songs</button>
                    </div><br>
                </div>
            </div>
            </form>
        </div>
    </div>
    <?php require 'parts/sidebar.parts.php';?>
</body>
<script>
    let burger = document.querySelector("#burger");
    let sidebar = document.querySelector('.sidebar');
    burger.onclick = function() {
        sidebar.classList.toggle('active');
    }

</script>
</html>