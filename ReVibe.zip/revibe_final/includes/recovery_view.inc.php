<?php

declare(strict_types=1);

// webpage outputs

function check_recovery_errors() {
    if (isset($_SESSION["errors_recovery"])) {
        $errors = $_SESSION['errors_recovery'];
        echo '<br>';

        foreach ($errors as $error) {
            echo '<p class="error"> ' . $error . '</p>';
        }

        unset($_SESSION["errors_recovery"]);
    } 
}
function show_reset_form(string $selector, string $validator) {
    if (empty($selector) || empty($validator)) {
        echo '<div>';
        echo '<p>Something went wrong, could not validate your request. Returning you to the Login Page</p>';
        echo '</div>';
        header('refresh: 5; index.php');
    } else {
        if (ctype_xdigit($selector) !== false && ctype_xdigit($validator) !== false) {
            echo '<form action="includes/reset-password.inc.php" method="POST" class="form">';
            echo '<img src="webimages/REVIBE.svg" class="mobile_logo">';
            echo '<div>';
            echo '<h2>Type New Password</h2>';
            echo '</div>';
            echo '<div class="form-control">';
            echo "<input type='password' name='pwd' id='newPassword' placeholder=''>";
            echo '<label for="password">Password</label>';
            echo '</div>';
            echo '<div class="form-control">';
            echo "<input type='password' name='cpwd' id='confirmPassword' placeholder=''>";
            echo '<label for="cpassword">Confirm Password</label>';
            echo '</div>';
            echo "<input type='hidden' name='selector' value='$selector'>";
            echo "<input type='hidden' name='validator' value='$validator'>";
            echo "<button type='submit' name='reset-pwd' class='btn-login'>Reset Password</button>";
            echo '</form>';
        }
    }
}