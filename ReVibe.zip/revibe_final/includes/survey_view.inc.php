<?php

declare(strict_types=1);


function show_open(int $uid) {
    echo "
    <p class='big bold'>Ready to answer the survey? You can access it through the link below.</p><br>
                <h1>
                <ul class='links'>
                <li><a href='https://forms.gle/fuSWALvJZFZM3upf9' class='ltext' target='_blank' rel='noopener noreferrer'>Survey Assessment (Google Forms) <i class='bx bx-link-external'></i></a></li>
                </ul>
                </h1><br>
                <form action='includes/update_status.inc.php' method='post'>
            <button class='btn-login' name='submit' type='submit' value='$uid+|+survey_done'> I have answered the Survey</button>
        </form><br>
    ";
}

function show_closed() {
    echo "
    <p class='big bold'>The Google Forms link will be available after <i class='underlined'>5 days</i> from account creation. In the meantime, you can access a pdf file of the survey below. Please keep in mind that you will answer an <i class='underlined'>actual online form</i>, not submit an answered copy of the pdf file. </p><br>
                <h1><ul class='links'>
                    <li><a href='forms/SurveyQuestionnaire.pdf' class='ltext' target='_blank' rel='noopener noreferrer'>Survey Form (PDF) <i class='bx bx-link-external'></i></a></li>
                </ul>
                </h1><br>
    ";
}

function show_done() {
    echo "
    <br><p class='big bold'>Thank you for answering the survey!</p><br>
    <h1><ul class='links'>
                <li><a href='https://forms.gle/fuSWALvJZFZM3upf9' class='ltext' target='_blank' rel='noopener noreferrer'>Survey Assessment (Google Forms) <i class='bx bx-link-external'></i></a></li>
                </ul> </h1>
    ";
}