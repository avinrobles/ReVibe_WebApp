<?php

//functions
declare(strict_types=1);

function search_track(string $name, string $artist) {
    $encoded = urlencode("$name by $artist");
    $qi = 'get from google cloud api services';


    // $headers = [
    //     "Authorization:"
    // ];
    $body = "?part=snippet&maxResults=1&q=$encoded&regionCode=PH&type=video&videoEmbeddable=true&key=$qi";
    $url = "https://youtube.googleapis.com/youtube/v3/search" . $body;

    $ch = curl_init();

    curl_setopt_array($ch, [
        #CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_URL => $url,
    ]);

    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    return $data;
}
