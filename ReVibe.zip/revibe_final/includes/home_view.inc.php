<?php

declare(strict_types=1);

// For website outputs

function output_username() {
    if (isset($_SESSION['user_id'])) {
        echo htmlspecialchars($_SESSION["user_username"]);
        /*print_r($_SESSION);*/
    } else {
        echo "You are not logged in... something went wrong :(";
    }
}