<?php

//functions
declare(strict_types=1);

function is_file_type_invalid(string $fileExt) { 
    $allowed = array('jpg', 'jpeg', 'png');

    if (!in_array($fileExt, $allowed)) {
        return true;
    } else {
        return false;
    }

}

function is_empty(string $inText) {
    if (empty($inText)) {
        return true;       
    } else {
        return false;
    }
}

function get_ext(string $fileName) {
    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));
    return $fileActualExt;
}

function save_file_to_preds(string $actualExt, string $fileTmpName) {
    $fileNameNew = "placed" . uniqid('', true).".".$actualExt;
    $fileDestination = '../preds/'.$fileNameNew;
    move_uploaded_file($fileTmpName, $fileDestination);
    return $fileDestination;
}

function new_file_name(string $imLoc) {
    $exploded = explode('/',$imLoc);
    $key = array_key_last($exploded);
    $exploded[$key] = 'processed_'.$exploded[$key];
    $file = explode( '.', $exploded[$key]);
    $k2 = array_key_last($file);
    $file[$k2] = 'jpg';
    $exploded[$key] = implode('.', $file);
    $new = implode('/', $exploded);
    return $new;
}

function save_image(string $img, string $imLoc) {
    $ifp = fopen( $imLoc, 'wb' ); 
    fwrite($ifp, base64_decode($img));
    fclose($ifp);
}

function get_emo_pref(string $prediction, array $userPref) {
    if ($prediction == 'happy') {
        return $userPref['when_happy'];
    } elseif ($prediction == 'sad') {
        return $userPref['when_sad'];
    } elseif ($prediction == 'angry') {
        return $userPref['when_angry'];
    } elseif ($prediction == 'fear') {
        return $userPref['when_fear'];
    } elseif ($prediction == 'surprise') {
        return $userPref['when_surprise'];
    }
}

function decision_level_fusion(float $imgPred, float $textPred, float $imgWeight, float $textWeight) {
    return ($imgPred*$imgWeight) + ($textPred*$textWeight);
}

function arr_val_float(array $arr) {
    return array_map('floatval', $arr);
}

function get_final_arr_pred(array $imgArr, array $txtArr, float $imgWeight, float $txtWeight) {
    $fusedPrediction = [
        "happy" => decision_level_fusion($imgArr["happy"], $txtArr["happy"], $imgWeight, $txtWeight),
        "sad" => decision_level_fusion($imgArr["sad"], $txtArr["sad"], $imgWeight, $txtWeight),
        "angry" => decision_level_fusion($imgArr["angry"], $txtArr["angry"], $imgWeight, $txtWeight),
        "fear" => decision_level_fusion($imgArr["fear"], $txtArr["fear"], $imgWeight, $txtWeight),
        "surprise" => decision_level_fusion($imgArr["surprise"], $txtArr["surprise"], $imgWeight, $txtWeight)
    ];
    return $fusedPrediction;
}

function get_final_pred(array $fusedPrediction) {
    $finalPredictionArray = array_keys($fusedPrediction, max($fusedPrediction));
    return $finalPredictionArray[0];
}