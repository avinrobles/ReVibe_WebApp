<?php

//interacts with db

declare(strict_types=1);

function get_expires_at(object $pdo) {
    $query = "SELECT expires_at FROM websetting WHERE setting_id = 1;";
    $stmt = $pdo->prepare($query);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
}

function update_token(object $pdo, string $token, string $token_type, int $expires_at) {
    $query = "UPDATE websetting SET setting_value1 = :token, setting_value2 = :token_type, expires_at = :expires_at WHERE setting_id = 1;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":token", $token);
    $stmt->bindParam(":token_type", $token_type);
    $stmt->bindParam(":expires_at", $expires_at);
    $stmt->execute();
}

function get_db_token(object $pdo) {
    $query = "SELECT * FROM websetting WHERE setting_id = 1;";
    $stmt = $pdo->prepare($query);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
}

function update_preferences(object $pdo, int $uid, string $genre1, string $genre2, string $fav_track, string $fav_artist, string $when_happy, string $when_sad, string $when_angry, string $when_surprise, string $when_fear, string $when_sunny, string $when_rainy, string $when_hot, string $when_cold) {
    $query = "UPDATE userpreferences SET genre1 = :genre1, 
    pref_status = 'personal',
    genre2 = :genre2,
    fav_track = :fav_track, 
    fav_artist = :fav_artist, 
    when_happy = :when_happy, 
    when_sad = :when_sad, 
    when_angry = :when_angry, 
    when_surprise = :when_surprise,  
    when_fear = :when_fear,
    when_sunny = :when_sunny,
    when_rainy = :when_rainy,
    when_hot = :when_hot,
    when_cold = :when_cold
    WHERE users_id = $uid;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":genre1", $genre1);
    $stmt->bindParam(":genre2", $genre2);
    $stmt->bindParam(":fav_artist", $fav_artist);
    $stmt->bindParam(":fav_track", $fav_track);
    $stmt->bindParam(":when_happy", $when_happy);
    $stmt->bindParam(":when_sad", $when_sad);
    $stmt->bindParam(":when_angry", $when_angry);
    $stmt->bindParam(":when_surprise", $when_surprise);
    $stmt->bindParam(":when_fear", $when_fear);
    $stmt->bindParam(":when_sunny", $when_sunny);
    $stmt->bindParam(":when_rainy", $when_rainy);
    $stmt->bindParam(":when_hot", $when_hot);
    $stmt->bindParam(":when_cold", $when_cold);
    $stmt->execute();
}

function get_user_preferences(object $pdo, int $uid) {
    $query = "SELECT * FROM userpreferences WHERE users_id = $uid;";
    $stmt = $pdo->prepare($query);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
}

function add_new_recommendation(object $pdo, int $uid, int $createdAt, string $recoType, string $subType, string $recos) {
    $query = "INSERT INTO recommendations (users_id, created_at, reco_type, subtype, recos_json) VALUES (:id, :createdat, :recotype, :subtype, :recos);";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":id", $uid);
    $stmt->bindParam(":createdat", $createdAt);
    $stmt->bindParam(":recotype", $recoType);
    $stmt->bindParam(":subtype", $subType);
    $stmt->bindParam(":recos", $recos);
    $stmt->execute();
}

function add_new_recommendation_emo(object $pdo, int $uid, int $createdAt, string $recoType, string $subType,  string $status, string $replaceStat, string $recos, string $inputText, string $imageLoc, string $predInfo) {
    $query = "INSERT INTO recommendations (users_id, created_at, reco_type, subtype, is_correct_prediction, replacement_to, recos_json, input_text, input_image_loc, pred_info_json) VALUES (:id, :createdat, :recotype, :subtype, :stat, :replaces, :recos, :intext, :imloc, :predinfo);";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":id", $uid);
    $stmt->bindParam(":createdat", $createdAt);
    $stmt->bindParam(":recotype", $recoType);
    $stmt->bindParam(":subtype", $subType);
    $stmt->bindParam(":stat", $status);
    $stmt->bindParam(":replaces", $replaceStat);
    $stmt->bindParam(":recos", $recos);
    $stmt->bindParam(":intext", $inputText);
    $stmt->bindParam(":imloc", $imageLoc);
    $stmt->bindParam(":predinfo", $predInfo);
    $stmt->execute();
}

function update_recommendation(object $pdo, int $uid, int $createdAt, string $subType, string $status, string $replaceStat) {
    $query = "UPDATE recommendations SET is_correct_prediction = :stat,
    replacement_to = :replaces,
    subtype = :subtype
    WHERE users_id = :id AND created_at = :createdat;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":createdat", $createdAt);
    $stmt->bindParam(":id", $uid);
    $stmt->bindParam(":subtype", $subType);
    $stmt->bindParam(":stat", $status);
    $stmt->bindParam(":replaces", $replaceStat);
    $stmt->execute();
}

function add_replacement_recommendation(object $pdo, int $uid, int $createdAt, string $recoType, string $subType,  string $status, string $replaceStat, string $recos) {
    $query = "INSERT INTO recommendations (users_id, created_at, reco_type, subtype, is_correct_prediction, replacement_to, recos_json) 
    VALUES (:id, :createdat, :recotype, :subtype, :stat, :replaces, :recos);";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":id", $uid);
    $stmt->bindParam(":createdat", $createdAt);
    $stmt->bindParam(":recotype", $recoType);
    $stmt->bindParam(":subtype", $subType);
    $stmt->bindParam(":stat", $status);
    $stmt->bindParam(":replaces", $replaceStat);
    $stmt->bindParam(":recos", $recos);
    $stmt->execute();
}
