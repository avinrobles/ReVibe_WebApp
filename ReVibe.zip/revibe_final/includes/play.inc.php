<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $val = explode('+|+', $_POST['val']);
    $tid = $val[0];
    $name = $val[1];
    $artist = $val[2];

    try {
        require_once 'dbh.inc.php';
        require_once 'youtube_model.inc.php';
        require_once 'youtube_contr.inc.php';
        require_once 'youtube_view.inc.php';

        // ERROR HANDLERS

        $errors = [];

        if (!$tid || !$name || !$artist) {
            $errors['invalid_values'] = 'Received invalid values, if you see this, please report to support@revibe.fun.';
        }


        if ($errors) {
            //echo errors, through view
            display_errors($errors);
            $pdo = null;
            $stmt = null;
            die();
        }
        //if no errors, do these

        //function check  and get track info if id is present in ytlinks table in db
        $savedTrackInfo = get_track($pdo, $tid); // has value of false if not yet in table
        
        if ($savedTrackInfo) {
            //echo $savedTrackInfo['ytid'];
            play_track($savedTrackInfo['ytid'], $name, $artist);

        } else {
            // search track via youtube_session
            $ytReply = search_track($name, $artist);
            $ytid = $ytReply['items'][0]['id']['videoId'];
            
            // save response
            add_track($pdo, $tid, $ytid);
            play_track($ytid, $name, $artist);
        }

        //always have this at the end
        $ytReply = null;
        $pdo = null;
        $stmt = null;
        die();

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    echo 'not getting GET';
    die();
}