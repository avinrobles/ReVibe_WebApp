<?php

declare(strict_types=1);

function is_empty_input(string $username, string $pwd, string $cpwd, string $email,  int $age) {
    
    if (empty($username) || empty($pwd) || empty($cpwd) || empty($email) || empty($age)) {
        return true;       
    }
    else {
        return false;
    }

}

function is_email_invalid(string $email) {
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return true;       
    } else {
        return false;
    }

}

function are_passwords_different(string $pwd, string $cpwd) {
    
    if ($pwd !== $cpwd) {
        return true;       
    } else {
        return false;
    }

}

function is_age_invalid(int $age) {
    
    if ($age < 18) {
        return true;       
    } else {
        return false;
    }

}

function is_username_taken(object $pdo, string $username) {

    if (get_username($pdo, $username)) {
        return true;       
    } else {
        return false;
    }

}

function is_email_registered(object $pdo, string $email) {

    if (get_email($pdo, $email)) {
        return true;       
    } else {
        return false;
    }

}

function create_user(object $pdo, string $username, string $pwd, string $email,  int $age) {
    set_user($pdo, $username, $pwd, $email, $age);
}

function is_username_valid(string $usn) {
    $pattern = "/^[a-zA-Z0-9]*$/";
    return preg_match($pattern, $usn);
}