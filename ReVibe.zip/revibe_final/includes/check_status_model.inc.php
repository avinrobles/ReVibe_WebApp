<?php

//interacts with db

declare(strict_types=1);

function get_status(object $pdo, int $id) {
    $query = "SELECT pref_status FROM userpreferences WHERE users_id = :id;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":id", $id);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
}

function get_user_status(object $pdo, int $id) {
    $query = "SELECT user_type FROM users WHERE id = :id;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":id", $id);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
}

function set_to_new(object $pdo, int $uid, string $status) {
    $query = "UPDATE users SET user_type = :stat WHERE id = :id;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":id", $uid);
    $stmt->bindParam(":stat", $status);
    $stmt->execute();
}