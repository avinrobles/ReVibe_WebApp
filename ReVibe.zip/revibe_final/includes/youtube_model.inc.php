<?php

//interacts with db

declare(strict_types=1);

function get_track(object $pdo, string $tid) {
    $query = "SELECT * FROM ytlinks WHERE tid = :tid;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":tid", $tid);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
}

function add_track(object $pdo, string $tid, string $ytid) {
    $query = "INSERT INTO ytlinks (tid, ytid) VALUES (:tid, :ytid);";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":tid", $tid);
    $stmt->bindParam(":ytid", $ytid);
    $stmt->execute();
}