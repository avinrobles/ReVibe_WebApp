<?php

declare(strict_types=1);

function display_errors(array $errors) {
    foreach ($errors as $error) {
        echo '<p class="error center bold"> ' . $error . '</p>';
    }
}

function play_track(string $ytid, string $name, string $artist){
    echo "
    <div>
    <iframe width='420' height='315' src='https://www.youtube.com/embed/$ytid?autoplay=1' class='yt-player'></iframe>
    </div>
    <div class='big bold invis-on-mob'> Now Playing $name by $artist
    </div>
    ";
}