<?php

declare(strict_types=1);

// communicates with the db

function delete_active_token(object $pdo, string $email) {
    $query = "DELETE FROM pwdReset WHERE pwdResetEmail = :email;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":email", $email);
    $stmt->execute();
}

function new_active_token(object $pdo,  string $email, string $selector, string $token, string $expires) {
    $options = [
        'cost' => 12
    ];
    $hashedToken = password_hash($token, PASSWORD_BCRYPT, $options);

    $query = "INSERT INTO pwdReset (pwdResetEmail, pwdResetSelector, pwdResetToken, pwdResetExpires) VALUES (:email, :selector, :token, :expires);";
    $stmt = $pdo->prepare($query);

    $stmt->bindParam(":email", $email);
    $stmt->bindParam(":selector", $selector);
    $stmt->bindParam(":token", $hashedToken);
    $stmt->bindParam(":expires", $expires);
    $stmt->execute();
}

function get_email(object $pdo, string $email) {
    $query = "SELECT email FROM users WHERE email = :email;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":email", $email);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
}


function check_selector(object $pdo, string $selector, int $currentTime) {
    $query = "SELECT * FROM pwdReset WHERE pwdResetSelector = :selector AND pwdResetExpires >= :currentTime;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":selector", $selector);
    $stmt->bindParam(":currentTime", $currentTime);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
}

function check_emails(object $pdo, string $tokenEmail) {
    $query = "SELECT email FROM users WHERE email = :tokenEmail;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":tokenEmail", $tokenEmail);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
}


function update_pwd(object $pdo, string $tokenEmail, string $pwd) {
    $options = [
        'cost' => 12
    ];

    $hpwd= password_hash($pwd, PASSWORD_BCRYPT, $options);
    $query = "UPDATE users SET pwd = :hpwd WHERE email = :tokenEmail;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":tokenEmail", $tokenEmail);
    $stmt->bindParam(":hpwd", $hpwd);
    $stmt->execute();
}
