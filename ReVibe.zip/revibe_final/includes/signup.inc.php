<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = $_POST["username"];
    $pwd = $_POST["pwd"];
    $cpwd = $_POST["cpwd"];
    $email = strtolower($_POST["email"]);
    $age = $_POST["age"];
    $errors = [];
    

    try {
        
        require_once 'dbh.inc.php';
        require_once 'signup_model.inc.php';
        require_once 'signup_contr.inc.php';

        // ERROR HANDLERS
        

        if (is_empty_input($username, $pwd, $cpwd, $email, $age)) {
            $errors["empty_input"] = "Empty Inputs!";
        }
        if (is_email_invalid($email)) {
            $errors["invalid_email"] = "Invalid Email!";
        }
        if (!is_username_valid($username)) {
            $errors['invalid_username'] = 'Invalid Username! Only username with characters a-Z, 0-9 are allowed!';
        }
        if (is_username_taken($pdo, $username)) {
            $errors["username_taken"] = "Username Taken!";
        }
        if (is_email_registered($pdo, $email)) {
            $errors["email_used"] = "Email Already Used!";
        }
        if (are_passwords_different($pwd, $cpwd)) {
            $errors["passwords_different"] = "Passwords Are Not The Same!";
        }
        if (is_age_invalid($age)) {
            $errors["invalid_age"] = "Invalid Age!";
        }

        require_once 'config_session.inc.php';

        if ($errors) {
            $_SESSION["errors_signup"] = $errors;
            $signupData = [
                "username" => $username,
                "email" => $email,
                "age" => $age
            ];

            $_SESSION["signup_form"] = $signupData;
            $pdo = null;
            $stmt = null;
        
            header("location: ../signup.php");
            die();
            
            
        }

        create_user($pdo, $username, $pwd, $email, $age);

        if (isset($_SESSION["errors_signup"])) {
            unset($_SESSION["errors_signup"]);
        }

        header("location: ../index.php?signup=success");

        $pdo = null;
        $stmt = null;

        die();

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("location: ../signup.php");
    die();
}