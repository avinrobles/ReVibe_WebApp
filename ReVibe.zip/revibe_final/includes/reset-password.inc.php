<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {

   $selector = $_POST["selector"];
   $validator = $_POST["validator"];
   $pwd = $_POST["pwd"];
   $cpwd = $_POST["cpwd"];
   $currentTime = time();

    try {
        require_once 'dbh.inc.php';
        require_once 'recovery_model.inc.php';
        require_once 'recovery_contr.inc.php';

        // ERROR HANDLERS

        $errors = [];
        if (is_empty($pwd, $cpwd)) {
            $errors["empty_input"] = "Empty Inputs!";
        }

        if (are_passwords_different($pwd, $cpwd)) {
            $errors["diff_pass"] = "Passwords not the same!";
        }

        if (!$row = check_selector($pdo, $selector, $currentTime)) {
            $errors["request_error"] = "Request Error, please re-submit your request";
        }

        $tokenBin = hex2bin($validator);
        $tokenCheck = password_verify($tokenBin, $row["pwdResetToken"]);

        if ($tokenCheck === false) {
            $errors["request_error"] = "Request Error, please re-submit your request";
        }
        
        require_once 'config_session.inc.php';

        if ($errors) {
            $_SESSION["errors_recovery"] = $errors;

            header("location: ../recover-password.php?selector=" . $selector . "&validator=" . $validator);
            $pdo = null;
            $stmt = null;
            die();
        }

        if ($tokenCheck === true) {
            $tokenEmail = $row['pwdResetEmail'];
            var_dump($row);
            $result = check_emails($pdo, $tokenEmail);
            var_dump($result);
            if ($tokenEmail !== $result['email']) {
                echo 'There was an error';
                $pdo = null;
                $stmt = null;
                die();
            } else {
                update_pwd($pdo, $tokenEmail, $pwd);
            }
            
        }

        delete_active_token($pdo, $tokenEmail);

        //always have this at the end
        header("Location: ../index.php?pwdreset=success");
        $pdo = null;
        $stmt = null;
        die();

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("location: ../recover-password.php");
    die();
}