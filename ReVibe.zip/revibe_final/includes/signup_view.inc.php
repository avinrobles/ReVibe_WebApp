<?php

declare(strict_types=1);

// For website outputs

function check_signup_errors() {
    if (isset($_SESSION["errors_signup"])) {
        $errors = $_SESSION['errors_signup'];


        foreach ($errors as $error) {
            echo '<p class="error"> ' . $error . '</p>';
        }

        unset($_SESSION["errors_signup"]);
    } else if (isset($_GET["signup"]) && $_GET["signup"] === "success") {
        echo '<p class="success">Signup Successfull!</p>';
    }
}

function signup() {
    echo '<div class="form-control">';
    if (isset($_SESSION["signup_form"]["username"]) && !isset($_SESSION["errors_signup"]['username_taken'])) {
        echo '<input type="text" id="newUsername" name="username" placeholder=" "  value="' . $_SESSION["signup_form"]["username"] . '" required maxlength="32">';
    } else {
        echo '<input type="text" id="newUsername" name="username" placeholder=" " required maxlength="32">';
    }
    echo '<label for="newUsername">Username</label>';
    echo '</div>';
    echo '<div class="form-control">';

    if (isset($_SESSION["signup_form"]["email"]) && !isset($_SESSION["errors_signup"]['email_used']) && !isset($_SESSION["errors_signup"]['invalid_email'])) {
        echo '<input type="email" id="email" name="email" placeholder=" " value="' . $_SESSION["signup_form"]["email"] . '"required>';
    } else {
        echo '<input type="email" id="email" name="email" placeholder=" " required>';
    }

    echo '<label for="email">Email</label>';
    echo '</div>';
    echo '<div class="form-control">';
    echo '<input type="password" id="newPassword" name="pwd" placeholder=" " required>';
    echo '<label for="newPassword">Password</label>';
    echo '</div>';
    echo '<div class="form-control">';
    echo '<input type="password" id="confirmPassword" name="cpwd" placeholder=" " required>';
    echo '<label for="confirmPassword">Confirm Password</label>';
    echo '</div>';
    echo '<div class="form-control">';
    if (isset($_SESSION["signup_form"]["age"]) && !isset($_SESSION["errors_signup"]['invalid_age'])) {
        echo '<input type="number" id="age" name="age" value="' . $_SESSION["signup_form"]["age"] . '" step="1" min="18" required>';
    } else {
        echo '<input type="number" id="age" name="age" value="18" step="1" min="18" required>';
    }
    echo '<label for="age">Age*</label>';
    echo '</div>';
}