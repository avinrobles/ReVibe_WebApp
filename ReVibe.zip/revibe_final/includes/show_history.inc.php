<?php

// get preferences

require_once 'dbh.inc.php';
require_once 'recos_model.inc.php';

$history = get_recommendation_list($pdo, $_SESSION["user_id"]);



$pdo = null;
$stmt = null;
//var_dump($history);

