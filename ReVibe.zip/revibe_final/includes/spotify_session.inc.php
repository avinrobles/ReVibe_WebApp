<?php

declare(strict_types=1);

// Token expires after 1 hour, this refreshes the token.
function get_token() {
    $client_id = 'get in sporify developer dashboard';
    $client_secret = 'get in sporify developer dashboard';
    $url = 'https://accounts.spotify.com/api/token';
    $encoded = base64_encode($client_id.':'.$client_secret);

    $headers = [
        'Content-Type: application/x-www-form-urlencoded',
        "Authorization: Basic $encoded"
    ];

    $body = 'grant_type=client_credentials';

    $ch = curl_init();

    curl_setopt_array($ch, [
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_URL => $url,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $body
    ]);

    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    return $data;
}


// Searches Tracks
function search_tracks(string $token, string $token_type, string $query) {
    $headers = [
        "Authorization: $token_type $token"
    ];
    $encoded = urlencode($query);
    $body = "?q=$encoded&type=track&market=PH&limit=5";
    $url = "https://api.spotify.com/v1/search" . $body;


    $ch = curl_init();

    curl_setopt_array($ch, [
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_URL => $url,
    ]);

    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    return $data;
}

// Searches artists
function search_artists(string $token, string $token_type, string $query) {
    $headers = [
        "Authorization: $token_type $token"
    ];
    $encoded = urlencode($query);
    $body = "?q=$encoded&type=artist&market=PH&limit=5";
    $url = "https://api.spotify.com/v1/search" . $body;


    $ch = curl_init();

    curl_setopt_array($ch, [
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_URL => $url,
    ]);

    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    return $data;
}

// for getting genre lists, already used.
function get_genres(string $token, string $token_type) {
    $headers = [
        "Authorization: $token_type $token"
    ];

    $ch = curl_init();

    curl_setopt_array($ch, [
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_URL => 'https://api.spotify.com/v1/recommendations/available-genre-seeds',
        CURLOPT_RETURNTRANSFER => true
    ]);

    $response = curl_exec($ch);
    curl_close($ch);
    var_dump($response);
}


// getting recommendations limited to 10 tracks, takes min max energy and valence
function get_recommendations(string $token, string $token_type, string $favTrack, string $favArtist, string $genre1, string $genre2, float $targetEnergy, float $targetValence) {
    $headers = [
        "Authorization: $token_type $token"
    ];
    $body = "?limit=10&market=PH&seed_artists=$favArtist&seed_genres=$genre1%2C$genre2&seed_tracks=$favTrack&target_energy=$targetEnergy&target_valence=$targetValence";
    $url = "https://api.spotify.com/v1/recommendations" . $body;

    $ch = curl_init();

    curl_setopt_array($ch, [
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_URL => $url,
    ]);

    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    return $data;
}



// ['sunny', 'rainy', 'hot', 'cold']
// Energy before Valence
function get_weather_recos(string $weather, string $token, string $token_type, string $favTrack, string $favArtist, string $genre1, string $genre2) {
    if ($weather == 'sunny') {
        return get_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.5, 1, 0.5, 1);
    } elseif ($weather == 'rainy') {
        return get_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.5, 1, 0.5, 1);
    } elseif ($weather == 'hot') {
        return get_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.5, 1, 0.5, 1);
    } elseif ($weather == 'cold') {
        return get_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.5, 1, 0.5, 1);
    }  
}

// Energy before Valence
function get_emotion_recos(string $preference, string $token, string $token_type, string $favTrack, string $favArtist, string $genre1, string $genre2) {
    if ($preference == 'happy') {
        return get_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.875, 0.82);
    } elseif ($preference == 'pleased') {
        return get_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.625, 0.82);
    } elseif ($preference == 'relaxed') {
        return get_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.375, 0.82);
    } elseif ($preference == 'peaceful') {
        return get_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.125, 0.82);
    } elseif ($preference == 'excited') {
        return get_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.875, 0.5);
    } elseif ($preference == 'calm') {
        return get_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.5, 0.5);
    } elseif ($preference == 'sleepy') {
        return get_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.125, 0.5);
    } elseif ($preference == 'angry') {
        return get_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.875, 0.17);
    } elseif ($preference == 'nervous') {
        return get_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.625, 0.17);
    } elseif ($preference == 'bored') {
        return get_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.375, 0.17);
    } elseif ($preference == 'sad') {
        return get_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.125, 0.17);
    }
}

// function get_rest_recommendations(string $token, string $token_type, string $favTrack, string $favArtist, string $genre1, string $genre2, float $energy, float $loudness, float $valence, float $acousticness, float $instrumentalness) {
//     $headers = [
//         "Authorization: $token_type $token"
//     ];
//     $body = "?limit=10&market=PH&seed_artists=$favArtist&seed_genres=$genre1%2C$genre2&seed_tracks=$favTrack&target_energy=$energy&target_valence=$valence&target_loudness=$loudness&target_acousticness=$acousticness&target_instrumentalness=$instrumentalness";
//     $url = "https://api.spotify.com/v1/recommendations" . $body;

//     $ch = curl_init();

//     curl_setopt_array($ch, [
//         CURLOPT_HTTPHEADER => $headers,
//         CURLOPT_RETURNTRANSFER => true,
//         CURLOPT_URL => $url,
//     ]);

//     $response = curl_exec($ch);
//     curl_close($ch);
//     $data = json_decode($response, true);
//     return $data;
// }

function get_rest_recommendations(string $token, string $token_type, string $favTrack, string $favArtist, string $genre1, string $genre2, float $energy, float $loudness, float $valence, float $acousticness, float $instrumentalness) {
    $headers = [
        "x-rapidapi-host: spotify23.p.rapidapi.com",
        'x-rapidapi-key: 79f8ddfbb1msh8327eadd9db0557p139bcejsn7abfcfcad499'
    ];
    $body = "?limit=10&market=PH&seed_artists=$favArtist&seed_genres=$genre1%2C$genre2&seed_tracks=$favTrack&target_energy=$energy&target_valence=$valence&target_loudness=$loudness&target_acousticness=$acousticness&target_instrumentalness=$instrumentalness";
    $url = "https://spotify23.p.rapidapi.com/recommendations/" . $body;

    $ch = curl_init();

    curl_setopt_array($ch, [
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_URL => $url,
    ]);

    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    return $data;
}

// energy, loudness, valence, acousticness, instrumentalness
function get_relax_recos(string $token, string $token_type, string $favTrack, string $favArtist, string $genre1, string $genre2) {
    return get_rest_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.539, -9.017, 0.365, 0.327, 0.103);
}
// energy, loudness, valence, acousticness, instrumentalness
function get_sleep_recos(string $token, string $token_type, string $favTrack, string $favArtist, string $genre1, string $genre2) {
    return get_rest_recommendations($token, $token_type, $favTrack, $favArtist, $genre1, $genre2, 0.270, -13.526, 0.184, 0.491, 0.154);
}