<?php


if ($_SERVER["REQUEST_METHOD"] === "GET") {

   $query = $_GET["query"];
   $type = $_GET["type"];
   $currentTime = time();
   
   //echo $_GET;

   if (!$query) {
    echo '<p class="error bold">No input! Please type your search input and try again.</p>';
    die();
   }


    try {
        require_once 'dbh.inc.php';
        require_once 'spotify_session.inc.php';
        require_once 'spotify_model.inc.php';
        require_once 'search_view.inc.php';

        $time = get_expires_at($pdo);

        // check if token is expired, 5 minute boundary
        if (($time['expires_at']-$currentTime) < 300) {
            // if expired, refresh token
            $values = get_token();
            $expiresIn = time() + 3600; 
            update_token($pdo, $values["access_token"], $values["token_type"], $expiresIn);
        }

        $token = get_db_token($pdo);

        if ($type == 'track') {
            $results = search_tracks($token["setting_value1"], $token["setting_value2"], $query);
            $tracks = $results["tracks"]["items"];
            show_tracks($tracks);

        } elseif ($type == 'artist') {
            $results = search_artists($token["setting_value1"], $token["setting_value2"], $query);
            $artists = $results["artists"]["items"];
            show_artists($artists);
        }

        $pdo = null;
        $stmt = null;
        die();

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("location: ../preference.php");
    die();
}