<?php
//interacts with db
declare(strict_types=1);

function get_recommendation_list(object $pdo, int $uid) {
    $query = "SELECT users_id, created_at, reco_type, subtype FROM recommendations WHERE users_id = :id;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":id", $uid);
    $stmt->execute();

    $result = $stmt->fetchAll(PDO::FETCH_DEFAULT);
    return $result;
}

function get_recommendation(object $pdo, int $uid, int $rid) {
    $query = "SELECT * FROM recommendations WHERE users_id = :id AND created_at = :rid;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":id", $uid);
    $stmt->bindParam(":rid", $rid);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
}