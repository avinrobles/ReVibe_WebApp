<?php

declare(strict_types=1);

// For website outputs

function check_login_errors() {
    if (isset($_SESSION["errors_login"])) {
        $errors = $_SESSION['errors_login'];
        echo '<br>';

        foreach ($errors as $error) {
            echo '<p class="error"> ' . $error . '</p>';
        }

        unset($_SESSION["errors_login"]);
    } else if (isset($_GET["signup"]) && $_GET["signup"] === "success") {
        echo '<p class="success">Signup Successfull!</p>';
    }

}

function check_pwdreset_status() {
    if (!isset($_GET["pwdreset"])) {
        
    } elseif ($_GET["pwdreset"] == 'success') {
        echo '<p class="success">Password Reset Successfull!</p>';
    }
}