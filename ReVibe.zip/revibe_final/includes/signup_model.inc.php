<?php

declare(strict_types=1);

//only one that interacts with db

function get_username(object $pdo, string $username) {
    $query = "SELECT username FROM users WHERE username = :username;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":username", $username);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
}

function get_email(object $pdo, string $email) {
    $query = "SELECT email FROM users WHERE email = :email;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":email", $email);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
}

function set_user(object $pdo, string $username, string $pwd, string $email,  int $age) {
    $query = "INSERT INTO users (username, pwd, email, age) VALUES (:username, :pwd, :email, :age)";
    $stmt = $pdo->prepare($query);

    $options = [
        'cost' => 12
    ];

    $hashedPwd = password_hash($pwd, PASSWORD_BCRYPT, $options);

    $stmt->bindParam(":username", $username);
    $stmt->bindParam(":email", $email);
    $stmt->bindParam(":pwd", $hashedPwd);
    $stmt->bindParam(":age", $age);
    $stmt->execute();

    // get user id
    $query = "SELECT id FROM users WHERE username = :username;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":username", $username);
    $stmt->execute(); 
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $uid = $result['id'];
    
    // use user id to add default preferences
    $query = "INSERT INTO userpreferences (users_id) VALUES (:user_id);";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":user_id", $uid);
    $stmt->execute();
}
