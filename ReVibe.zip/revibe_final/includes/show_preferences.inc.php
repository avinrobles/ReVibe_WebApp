<?php

// get preferences

require_once 'dbh.inc.php';
require_once 'spotify_model.inc.php';
require_once 'spotify_view.inc.php';

$prefs = get_user_preferences($pdo, $_SESSION["user_id"]);



$pdo = null;
$stmt = null;
//var_dump($prefs);

