<?php

declare(strict_types=1);

function show_tracks(array $tracks) {
    echo '<select name="favtrack" id="favtrack" class="selection variable-input">';
    foreach ($tracks as $track) {
        $name = $track['name'];
        $artist = $track["artists"][0]['name'];
        $nameValue = htmlspecialchars($name);
        $artistValue = htmlspecialchars($artist);
        $id = $track["id"];
        //echo $track['name']  . ' - ';
        //echo $track["artists"][0]['name'];
        //var_dump($track["id"]);
        echo "<option value='$id+$nameValue+$artistValue'>$name by $artist</option>";
    }
    echo '</select>';
}

function show_artists(array $artists) {
    echo '<select name="favartist" id="favartist" class="selection variable-input">';
    foreach ($artists as $artist) {
        //echo $artist['name'];
        $name = $artist['name'];
        $id = $artist['id'];
        $nameValue = htmlspecialchars($artist['name']);
        echo "<option value='$id+$nameValue'>$name</option>";
    }
    echo '</select>';
}