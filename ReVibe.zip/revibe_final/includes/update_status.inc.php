<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    require_once 'config_session.inc.php';

    $exploded = explode('+|+',$_POST['submit']);
    $uid = $_SESSION["user_id"];
    $newStatus = $exploded[1];
    
    try {
        require_once 'dbh.inc.php';
        require_once 'check_status_model.inc.php';
        require_once 'check_status_contr.inc.php';

        if (val_invalid($newStatus)) {
            echo $newStatus;
            echo 'something went wrong';
            $pdo = null;
            $stmt = null;
            header('Location: ../home.php');
            die();
        }


        set_to_new($pdo, $uid, $newStatus);
        echo 'state changed';

        $_SESSION["user_status"] = $newStatus;

        echo $newStatus;
        echo 'completed';
        //always have this at the end
        $pdo = null;
        $stmt = null;
        header('Location: ../home.php');
        die();

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header('Location: ../home.php');
    die();
}