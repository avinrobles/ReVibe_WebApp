<?php

declare(strict_types=1);

// For website outputs

function check_errors() {
    if (isset($_SESSION["errors_reco"])) {
        $errors = $_SESSION['errors_reco'];


        foreach ($errors as $error) {
            echo '<p class="error"> ' . $error . '</p>';
        }

        unset($_SESSION["errors_reco"]);
    } 
}

function display_text() {
    if (isset($_SESSION["reco_input"])) {
        echo $_SESSION['reco_input'];
        unset($_SESSION["reco_input"]);
    } 
}