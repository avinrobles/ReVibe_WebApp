<?php

// get preferences

require_once 'dbh.inc.php';
require_once 'recos_model.inc.php';

$list = get_recommendation($pdo, $_SESSION["user_id"], $_GET['r']);



$pdo = null;
$stmt = null;

