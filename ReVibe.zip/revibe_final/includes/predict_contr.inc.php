<?php

declare(strict_types=1);

// test api
function predict(string $in_text, string $im_loc) {
    $kay = 'changethis';
    $url = '127.0.0.1:8000/predict';

    $img = file_get_contents($im_loc);
    $encoded = base64_encode($img);

    #echo $encoded;

    $headers = [
        "qi: $kay",
        'Content-Type: application/json'
    ];

    $body = [
        'text' => $in_text,
        'face' => $encoded
    ];

    $ch = curl_init();

    curl_setopt_array($ch, [
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_URL => $url,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($body)
    ]);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        $error_msg = curl_error($ch);
        curl_close($ch);
        return $error_msg;
    }
    curl_close($ch);
    $data = json_decode($response, true);
    return $data;
}

function str_to_jpg(string $img, string $loc) {
    $file = fopen( $loc, 'wb' ); 
    fwrite( $file, base64_decode($img));
    fclose($file); 
    return $loc;
}