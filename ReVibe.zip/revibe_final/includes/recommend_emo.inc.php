<?php


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    require_once 'config_session.inc.php';


    $recoType = $_POST["type"];
    $uid = $_SESSION["user_id"];
    $currentTime = time();

    $inText = $_POST["text"];
    $file = $_FILES['img'];

    // for file checking
    $fileName = $file['name'];
    $fileTmpName = $file['tmp_name'];
    $fileSize = $file['size'];
    $fileError = $file['error'];
    $fileType = $file['type'];
   


    try {
        require_once 'dbh.inc.php';
        require_once 'spotify_session.inc.php';
        require_once 'spotify_model.inc.php';
        require_once 'spotify_contr.inc.php';
        require_once 'predict_contr.inc.php';
        require_once 'recommend_contr.inc.php';

        $errors = [];

        //error checking
        $actualExt = get_ext($fileName);

        if (is_file_type_invalid($actualExt)) {
            $errors['invalid_file_type'] = 'Invalid File Type!';
        }
        if (is_empty($inText)) {
            $errors['text_empty'] = 'No Input in text field!';
        }
        if ($fileError) {
            $errors['file_error'] = 'error uploading file!';
        }
        if ($fileSize > 3000000) {
            $errors['file_large'] = 'file size too large!';
        }

        require_once 'config_session.inc.php';
        
        if ($errors) {
            $_SESSION["errors_reco"] = $errors;
            $_SESSION["reco_input"] = $inText;       
            header("location: ../reco_emotion.php");
            die();
        }



        $imLoc = save_file_to_preds($actualExt, $fileTmpName);



        // conduct predict here through predict_contr.inc.php
        $inText = addslashes($inText);
        $apiResponse = predict($inText, $imLoc);

        // var_dump($apiResponse); // check values
        // echo '<br>';

        // check if there are errors from api
        if (isset($apiResponse['message']) && $apiResponse['message'] == 'Error') {
            $errors['api_error'] = 'Error encountered while predicting, please check instructions for guidance, if you still see this message after doing so, you can report it to support@revibe.fun';
            //echo 'Error encountered while predicting, please check instructions for guidance, if you still see this message after doing so, you can report it to support@revibe.fun';

        }  elseif (isset($apiResponse['detail']) && $apiResponse['detail'] == 'Unauthorized') {
            $errors['unauth'] = 'Unauthorized. If you see this error please report to support@revibe.fun.';

        } elseif (isset($apiResponse['message']) && $apiResponse['message'] == 'OK: complete') {
            // save the image from response
            $newFileNameLoc = new_file_name($imLoc);
            //echo $newFileNameLoc;
            save_image($apiResponse['prep_img'], $newFileNameLoc);
            //echo 'response image saved!';

        } else {$errors['unknown'] = 'Internal Error. If you see this error please report to support@revibe.fun.';}

        if ($errors) {
            $_SESSION["errors_reco"] = $errors;
            $_SESSION["reco_input"] = $inText;       
            header("location: ../reco_emotion.php");
            die();
        }

        

        // convert assoc string array to assoc float array
        $imagePrediction = arr_val_float($apiResponse['img_preds']);
        // var_dump($imagePrediction); // check values
        // echo '<br>';
        $textPrediction = arr_val_float($apiResponse['text_preds']);
        // var_dump($textPrediction);
        // echo '<br>';

        // now  43-57 //now changed to 5050 for no bias// Decision Level Fusion @ 40-60 in favor of text, returns an array of compound predictions
        $imageWeight = 0.43;
        $textWeight = 0.57;
        $fusedPrediction = get_final_arr_pred($imagePrediction, $textPrediction, $imageWeight, $textWeight);
        // var_dump($fusedPrediction); // check values
        // echo '<br>';

        // get string of final emotion prediction
        $finalPrediction = get_final_pred($fusedPrediction);
        // echo $finalPrediction; // check values
        // echo '<br>';

        // get user preferences
        $userPreferences =  get_user_preferences($pdo, $uid);
        $favTrack = select_id($userPreferences["fav_track"]);
        $favArtist = select_id($userPreferences["fav_artist"]);
        $genre1 = $userPreferences["genre1"];
        $genre2 = $userPreferences["genre2"];

        // Prepare to connect to spotify api
        // get token expires
        $time = get_expires_at($pdo);
        // check if token is expired, 5 minute boundary
        if (($time['expires_at']-$currentTime) < 300) {
            // if expired, refresh token
            $values = get_token();
            $expiresIn = time() + 3600; 
            update_token($pdo, $values["access_token"], $values["token_type"], $expiresIn);
            //echo 'renewed';
        }
        $token = get_db_token($pdo);


        // get preferred music as per prediction
        $musicPref = get_emo_pref($finalPrediction, $userPreferences);

        // get tracks via spotify api
        echo 'Getting tracks <br>';
        $tracks = get_emotion_recos($musicPref, $token["setting_value1"], $token["setting_value2"], $favTrack, $favArtist, $genre1, $genre2);
        if ($tracks) {
            echo 'Got tracks <br>';
        } else {
            echo 'Null tracks <br>';
        }
        
        // compile relevant prediction infos
        $predictionInfo = [
            "uid" => $uid,
            "received_text" => htmlspecialchars($apiResponse["in_text"]),
            "preprocessed_text" => htmlspecialchars($apiResponse["prep_text"]),
            "preprocessed_img_loc" => $newFileNameLoc,
            "prediction_text" => $textPrediction,
            "prediction_image" => $imagePrediction,
            "prediction_fused" => $fusedPrediction,
            "fusion_weights_img_txt" => [$imageWeight, $textWeight],
            "prediction_final" => $finalPrediction
        ];
        // encode to json
        $jsonifiedInfo = json_encode($predictionInfo);
        $jsonifiedTracks = json_encode($tracks);

        $subType = $finalPrediction . " - " . $musicPref;
        $status = 'pending';
        //var_dump($jsonified); // tells that $jsonified is a string

        // add to db
        add_new_recommendation_emo($pdo, $uid, $currentTime, $recoType, $subType, $status, $status, $jsonifiedTracks, htmlspecialchars($inText), $imLoc, $jsonifiedInfo);
        

        $pdo = null;
        $stmt = null;
        echo 'successful end, should be redirected';
        header("location: ../recommendation.php?r=$currentTime");
        die();

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("location: ../home.php");
    die();
}