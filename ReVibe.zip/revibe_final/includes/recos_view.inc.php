<?php

declare(strict_types=1);

function display_errors(array $errors) {
    foreach ($errors as $error) {
        echo '<p class="error center bold"> ' . $error . '</p>';
    }
}

function display_history(array $history) {
    echo '
    <table class="recos">
        <tr>
            <th>Date Created</th>
            <th>Type</th>
            <th></th>
        </tr>
    ';
    foreach ($history as $item) {
        $time = $item['created_at'];
        $time_dis = date("jS  F Y h:i:s A",($item['created_at'] + 25200 + 3600));
        $recoType = $item['reco_type'];
        $subtype = $item['subtype'];
        $eexploded = explode(' - ', $subtype);
        $e1 = $eexploded[0];
        $e2 = $eexploded[1];
        echo "
        <tr>
            <td>$time_dis</td>
            <td>$recoType | $e1 - $e2</td>
            <td class='center'><a href='recommendation.php?r=$time'> <button class='go-to'><i class='invis-on-mob'>See Recommendations </i><i class='vis-on-mob'>🎧</i></button></a></td>
        </tr>
        ";
    }
    echo '</table>';
}

function display_default() {
    echo "You don't have any recommendations yet, go to 'Home' and select 'New Music Recommendation to get started!";
}


function display_list(array $tracks) {
    $tracks = $tracks['tracks'];
    echo "<table class='recos'>
        <tr>
            <th>Song and Artist</th>
            <th class='center'>Play Here</th>
            <th colspan='1'><p class='center'>External Links</p></th>
        </tr>
    ";
    foreach ($tracks as $track) {
        $name = $track["name"];
        $tid = $track["id"];
        $artist = $track["artists"][0]['name'];
        $isExplicit = $track["explicit"];
        $exURL = $track["external_urls"]["spotify"];
        $encoded = urlencode("$name $artist");
        $value = htmlspecialchars("$tid+|+$name+|+$artist" );
        $ytURL = "https://www.youtube.com/results?search_query=$encoded";
        if (!$isExplicit && str_starts_with($exURL, 'https://open.spotify.com/')) {
            echo "
            <tr>
                <td>$name by $artist </td>
                <td class='center'>
                <form action='includes/play.inc.php' method='post' class='play_request'>
                <button class='go-to play-btn' type='submit' id='submit'> ▶ </button>
                <input type='hidden' name='to-play' value='$value' id='to-play'>
                </form>
                </td>
                <td class='center-center'>
                    <a href='$exURL' target='_blank' rel='noopener noreferrer'>
                    <button class='go-to spotify-btn'><div class='split-2-col'>
                    <div class='spotify-logo'></div><div class='invis-on-mob border-on'>Play on Spotify</div>
                    </div></button>
                    </a>
                </td>

            </tr>
            ";
        }
        // to add youtube external link, place this after before </tr> in foreach loop and set colspan to 2
            // <td>
            // <a href='$ytURL' target='_blank' rel='noopener noreferrer'>
            // <button class='go-to yt-btn'><i class='invis-on-mob'>Search on YouTube</i><i class='vis-on-mob'>🔎</i></button>
            // </a>
            // </td>
        // else {
        //     echo "
        //     <tr>
        //         <td>Song Labeled as Explicit</td>
        //         <td></td>
        //         <td></td>
        //         <td></td>
        //     </tr>
        //     ";
        // }
    }
    echo "</table>";  
}

function display_time(int $time) {
    $time = date("jS  F Y h:i:s A",($time + 25200 + 3600));
    echo $time;
}