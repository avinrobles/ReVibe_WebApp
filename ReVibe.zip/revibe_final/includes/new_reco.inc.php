<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    require_once 'config_session.inc.php';

    $uid = (int)$_SESSION["user_id"];
    $createdAt = (int)$_POST["createdat"];
    $predEmo = $_POST['predemo'];
    $correctEmo = $_POST["correctemo"];
    $wantNew= $_POST["wantnew"];
    $subType = $_POST['subtype'];
    $types = ['happy', 'sad', 'angry', 'fear', 'surprise'];
    $types2 = ['yes', 'no'];
    //var_dump($_POST);


    try {
        require_once 'dbh.inc.php';
        require_once 'spotify_model.inc.php';
        require_once 'spotify_session.inc.php';
        require_once 'spotify_contr.inc.php';
        require_once 'spotify_view.inc.php';

        // ERROR HANDLERS

        $errors = [];

        if (are_values_tampered($wantNew, $types2) || are_values_tampered($predEmo, $types) || are_values_tampered($correctEmo, $types)) {
            $errors["invalid_vals"] = "Received invalid values!";
        }


        if ($errors) {
            //echo errors, through view
            display_errors($errors);
            $pdo = null;
            $stmt = null;
            die();
        }
        //if no errors, do these

        // if prediction is correct
        if($predEmo == $correctEmo) {
            $status = 'YES';
            $replaceStat = 'not_needed';
            $subType = $subType . ' - correct';
            update_recommendation($pdo, $uid, $createdAt, $subType, $status, $replaceStat);
            echo 'Thank you for verifying! You can refresh the page to make this disappear.';

        // if prediction is incorrect and user declined new recommendation
        } elseif ($predEmo != $correctEmo && $wantNew == 'no') {
            $status = 'NO';
            $replaceStat = 'declined';
            $subType = $subType . ' - incorrect';
            update_recommendation($pdo, $uid, $createdAt, $subType, $status, $replaceStat);
            echo 'Thank you for verifying! You can refresh the page to make this disappear.';

        // if prediction is incorrect and user wants new recommendation
        } elseif ($predEmo != $correctEmo && $wantNew == 'yes') {
            //echo 'getting new songs....';
            $statusO = 'NO';
            $currentTime = time();
            $replaceStatO = (string)$currentTime;
            $createdAtO = $createdAt;
            $subTypeO = $subType . ' - incorrect';
            

            // get new recommendation

            $time = get_expires_at($pdo);
            $userPreferences =  get_user_preferences($pdo, $uid);
            $preference = get_preference_of_interest( $correctEmo,  $userPreferences);
            //send to function
            $favTrack = select_id($userPreferences["fav_track"]);
            $favArtist = select_id($userPreferences["fav_artist"]);
            $genre1 = $userPreferences["genre1"];
            $genre2 = $userPreferences["genre2"];

            //var_dump($userPreferences);
            // check if token is expired, 5 minute boundary
            if (($time['expires_at']-$currentTime) < 300) {
                // if expired, refresh token
                $values = get_token();
                $expiresIn = time() + 3600; 
                update_token($pdo, $values["access_token"], $values["token_type"], $expiresIn);
                //echo 'renewed';
            }

            $token = get_db_token($pdo);

            $tracks = get_emotion_recos($preference, $token["setting_value1"], $token["setting_value2"], $favTrack, $favArtist, $genre1, $genre2);
            //var_dump($tracks);
            // save new recommendation
            $recoType = 'emotion';
            $subType = "$correctEmo - $preference - replacement";
            $replaceStat = "replaces $createdAt";
            $status = 'Valid replace';
            $jsonified = json_encode($tracks);
            add_replacement_recommendation($pdo, $uid, $currentTime, $recoType, $subType, $status, $replaceStat, $jsonified);

            update_recommendation($pdo, $uid, $createdAt,  $subTypeO, $statusO,  $replaceStatO);
            echo 'Thank you for verifying!';
            echo "<br>You can view your new songs <a href='recommendation.php?r=$currentTime' class='ltext'>Here</a>.";

            $values = null;
            $pdo = null;
            $stmt = null;
        }




        //always have this at the end
        $values = null;
        $pdo = null;
        $stmt = null;
        die();

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("location: ../preference.php");
    die();
}

