<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    require_once 'config_session.inc.php';

    $uid = $_SESSION["user_id"];
    $genre1 = $_POST["genre1"];
    $genre2 = $_POST["genre2"];
    // will be reduced depending on the number of viable predicitons
    $when_happy = $_POST["happy"];
    $when_sad = $_POST["sad"];
    $when_angry = $_POST["angry"];
    $when_surprise = $_POST["surprise"];
    $when_fear = $_POST["fear"];
    $when_sunny = $_POST["sunny"];
    $when_rainy = $_POST["rainy"];
    $when_hot = $_POST["hot"];
    $when_cold = $_POST["cold"];
    //echo $fav_artist . '<br>';
    //echo $fav_track;

    $genres = [ "acoustic", "afrobeat", "alt-rock", "alternative", "ambient", "anime", "black-metal", "bluegrass", "blues", "bossanova", "brazil", "breakbeat", "british", "cantopop", "chicago-house", "children", "chill", "classical", "club", "comedy", "country", "dance", "dancehall", "death-metal", "deep-house", "detroit-techno", "disco", "disney", "drum-and-bass", "dub", "dubstep", "edm", "electro", "electronic", "emo", "folk", "forro", "french", "funk", "garage", "german", "gospel", "goth", "grindcore", "groove", "grunge", "guitar", "happy", "hard-rock", "hardcore", "hardstyle", "heavy-metal", "hip-hop", "holidays", "honky-tonk", "house", "idm", "indian", "indie", "indie-pop", "industrial", "iranian", "j-dance", "j-idol", "j-pop", "j-rock", "jazz", "k-pop", "kids", "latin", "latino", "malay", "mandopop", "metal", "metal-misc", "metalcore", "minimal-techno", "movies", "mpb", "new-age", "new-release", "opera", "pagode", "party", "philippines-opm", "piano", "pop", "pop-film", "post-dubstep", "power-pop", "progressive-house", "psych-rock", "punk", "punk-rock", "r-n-b", "rainy-day", "reggae", "reggaeton", "road-trip", "rock", "rock-n-roll", "rockabilly", "romance", "sad", "salsa", "samba", "sertanejo", "show-tunes", "singer-songwriter", "ska", "sleep", "songwriter", "soul", "soundtracks", "spanish", "study", "summer", "swedish", "synth-pop", "tango", "techno", "trance", "trip-hop", "turkish", "work-out", "world-music" ];

    $types = ['happy', 'pleased', 'relaxed', 'peaceful', 'excited', 'calm', 'sleepy', 'angry', 'nervous', 'bored', 'sad'];

    try {
        require_once 'dbh.inc.php';
        require_once 'spotify_model.inc.php';
        require_once 'spotify_session.inc.php';
        require_once 'spotify_contr.inc.php';
        require_once 'spotify_view.inc.php';

        // ERROR HANDLERS

        $errors = [];

        if (isset($_POST["favtrack"])) {
            $fav_track = $_POST["favtrack"];
        } else {
            $errors["empty_favtrack"] = "No Selected Track!";
        }

        if (isset( $_POST["favartist"])) {
            $fav_artist =  $_POST["favartist"];
        } else {
            $errors["empty_favtrack"] = "No Selected Artist!";
        }

        if (are_genres_same($genre1, $genre2)) {
            $errors["empty_input"] = "Genre inputs are the same!";
        }

        if (are_values_tampered($when_happy, $types) || are_values_tampered($when_sad, $types) || are_values_tampered($when_angry, $types) || are_values_tampered($when_surprise, $types) || are_values_tampered($when_fear, $types) || are_values_tampered($when_sunny, $types) || are_values_tampered($when_rainy, $types) || are_values_tampered($when_hot, $types) || are_values_tampered($when_cold, $types)) {
            $errors["invalid_type"] = "'Song Emotion Type' inputs are invalid!";
        }

        if (are_values_tampered($genre1, $genres) || are_values_tampered($genre2, $genres)) {
            $errors["invalid_genre"] = "'Song Genre' inputs are invalid!";
        }


        if ($errors) {
            //echo errors, through view
            display_errors($errors);
            $pdo = null;
            $stmt = null;
            die();
        }
        
        //if no errors, do these.
        //update preferences table in db
        update_preferences($pdo, $uid, $genre1, $genre2, $fav_track, $fav_artist, $when_happy, $when_sad, $when_angry, $when_surprise, $when_fear, $when_sunny, $when_rainy, $when_hot, $when_cold);




        //always have this at the end
        display_success();
        $pdo = null;
        $stmt = null;
        die();

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("location: ../preference.php");
    die();
}