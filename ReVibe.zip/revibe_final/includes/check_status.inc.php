<?php

// get preferences status

require_once 'dbh.inc.php';
require_once 'check_status_model.inc.php';
require_once 'check_status_contr.inc.php';

$result = get_status($pdo, $_SESSION["user_id"]);
$_SESSION["user_pref_status"] = $result['pref_status'];
if (is_default($result['pref_status'])) {  
    header('Location: preference.php');
}
//checking result
//var_dump($result);

