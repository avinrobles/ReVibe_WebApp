<?php

//functions
declare(strict_types=1);

function are_genres_same(string $genre1, string $genre2) {
    if ($genre1 === $genre2) {
        return true;
    } else {
        return false;
    }
}

function are_values_tampered(string $toCheck, array $toCheckFrom) {
    if (!in_array($toCheck, $toCheckFrom, true)) {
        return true;
    } else {
        return false;
    }
}

function select_id(string $data) {
    $exploded = explode('+', $data);
    return $exploded[0];
}

function get_preference_of_interest(string $emotion, array $userPref) {
    if ($emotion == 'happy') return $userPref['when_happy'];
    elseif ($emotion == 'sad') return $userPref['when_sad'];
    elseif ($emotion == 'angry') return $userPref['when_angry'];
    elseif ($emotion == 'fear') return $userPref['when_fear'];
    elseif ($emotion == 'surprise') return $userPref['when_surprise'];
    elseif ($emotion == 'sunny') return $userPref['when_sunny'];
    elseif ($emotion == 'rainy') return $userPref['when_rainy'];
    elseif ($emotion == 'hot') return $userPref['when_hot'];
    elseif ($emotion == 'cold') return $userPref['when_cold'];
}

