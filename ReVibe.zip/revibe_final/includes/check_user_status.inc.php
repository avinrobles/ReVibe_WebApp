<?php

// get preferences status

require_once 'dbh.inc.php';
require_once 'check_status_model.inc.php';
require_once 'check_status_contr.inc.php';

$userStatus = get_user_status($pdo, $_SESSION["user_id"]);
$_SESSION["user_status"] = $userStatus['user_type'];

if (is_pending($userStatus['user_type'])) {
    header('Location: agreement_forms.php?nu=y');
} 

//checking result
//var_dump($result);

