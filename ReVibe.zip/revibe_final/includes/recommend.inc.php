<?php


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    require_once 'config_session.inc.php';

    $recoType = $_POST["type"];
    $uid = $_SESSION["user_id"];
    $currentTime = time();

    try {
        require_once 'dbh.inc.php';
        require_once 'spotify_session.inc.php';
        require_once 'spotify_model.inc.php';
        require_once 'spotify_contr.inc.php';

        $errors = [];

        //check get and values
        if ($recoType == 'weather') {
            //echo 'weather selected';
            $weather = $_POST["weather"];
            if (are_values_tampered($weather, ['sunny', 'rainy', 'hot', 'cold'])) {
                $errors["invalid_values"] = "Error! Invalid Values!";
            }
            //echo $weather;
    
        } elseif ($recoType == 'relax') {
            //echo 'Relax selected';
    
        } elseif ($recoType == 'sleep') {
            //for sleep
            //echo 'Sleep selected';
        } else {
            $errors["invalid_type"] = 'Error! Invalid Type!';
        }

        if ($errors) {
            foreach ($errors as $error) {
                echo "$error<br>";
            }
            die();
        }

        $time = get_expires_at($pdo);
        $userPreferences =  get_user_preferences($pdo, $uid);
        //send to function
        $favTrack = select_id($userPreferences["fav_track"]);
        $favArtist = select_id($userPreferences["fav_artist"]);
        $genre1 = $userPreferences["genre1"];
        $genre2 = $userPreferences["genre2"];

        // check if token is expired, 5 minute boundary
        if (($time['expires_at']-$currentTime) < 300) {
            // if expired, refresh token
            $values = get_token();
            $expiresIn = time() + 3600; 
            update_token($pdo, $values["access_token"], $values["token_type"], $expiresIn);
            //echo 'renewed';
        }

        $token = get_db_token($pdo);

        if ($recoType == 'weather') {
            echo 'weather selected';
            $wanted = get_preference_of_interest($weather, $userPreferences);
            //echo $wanted;
            $response = get_emotion_recos($wanted, $token["setting_value1"], $token["setting_value2"], $favTrack, $favArtist, $genre1, $genre2);
            // Save response to db in 'recommendations' table
            $jsonified = json_encode($response);
            $subType = $weather . " - " . $wanted;
            echo $subType;
            add_new_recommendation($pdo, $uid, $currentTime, $recoType, $subType, $jsonified);
            //var_dump($jsonified); tells that $jsonified is a string
            
        } elseif ($recoType == 'relax') {
            echo 'Relax selected';
            $response = get_relax_recos($token["setting_value1"], $token["setting_value2"], $favTrack, $favArtist, $genre1, $genre2);
            // Save response to db in 'recommendations' table
            $jsonified = json_encode($response);
            $recoType = 'stress relief';
            $subType = 'rest - relaxation'; 
            echo $subType;
            add_new_recommendation($pdo, $uid, $currentTime, $recoType, $subType, $jsonified);
            //var_dump($jsonified); tells that $jsonified is a string

        } elseif ($recoType == 'sleep') {
            echo 'Sleep selected';
            $response = get_sleep_recos($token["setting_value1"], $token["setting_value2"], $favTrack, $favArtist, $genre1, $genre2);
            // Save response to db in 'recommendations' table
            $jsonified = json_encode($response);
            $subType = 'sleep - sleep'; 
            echo $subType;
            add_new_recommendation($pdo, $uid, $currentTime, $recoType, $subType, $jsonified);
            //var_dump($jsonified); tells that $jsonified is a string
        } else {
            echo 'something went wrong :(';
            $pdo = null;
            $stmt = null;
            die();
        }

        $pdo = null;
        $stmt = null;
        //echo 'successful end';
        header("location: ../recommendation.php?r=$currentTime");
        die();

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("location: ../home.php");
    die();
}