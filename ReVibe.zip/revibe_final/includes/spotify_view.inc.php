<?php

declare(strict_types=1);

function display_errors(array $errors) {
    foreach ($errors as $error) {
        echo '<p class="error center bold"> ' . $error . '</p>';
    }
}

function display_success() {
    echo "<p class='success center bold'>Preferences Updated! Click the 'home' (<i class='bx bxs-home'></i>) icon on the sidebar to get started!</p>";
}

function display_fav_artist(string $fav_artist) {
    $arr = explode('+', $fav_artist);
    $id = $arr[0];
    $name = $arr[1];
    $nameDisplay = htmlspecialchars_decode($name);
    echo '<select name="favartist" id="favartist" class="selection variable-input">';
    echo "<option value='$id+$name'>$nameDisplay</option>";
    echo '</select>';
}

function display_fav_track(string $fav_track) {
    $fav_track = htmlspecialchars($fav_track);
    $arr = explode('+', $fav_track);
    $id = $arr[0];
    $name = $arr[1];
    $artist = $arr[2];
    $nameDisplay = htmlspecialchars_decode($name);
    $artistDisplay = htmlspecialchars_decode($artist);
    echo '<select name="favtrack" id="favtrack" class="selection variable-input">';
    echo "<option value='$id+$name+$artist'>$nameDisplay by $artistDisplay</option>";
    echo '</select>';
}

function display_selected_value(array $values, string $selected) {
    foreach ($values as $value) {
        $val = $value[0];
        $disp = $value[1];
        if ($val == $selected) {
            echo "<option value='$val' selected>$disp</option>";
        } else {
            echo "<option value='$val'>$disp</option>";
        }
    }
}
