<?php

//functions
declare(strict_types=1);

function is_default(string $status) {
    if ($status === "default") {
        return true;
    } else {
        return false;
    }
}

function is_pending(string $status) {
    if ($status === "icf pending") {
        return true;
    } else {
        return false;
    }
}

function val_invalid(string $status) { 
    $allowed = array('icf pending', 'survey_pending', 'survey_done');

    if (!in_array($status, $allowed)) {
        return true;
    } else {
        return false;
    }

}