<?php

declare(strict_types=1);

function display_first_time_user(int $uid) {
    echo ' <h1><br><p class="big">Before using this webapp, please submit your signed ICF in the google forms link below. <br><br>
    
    
    <ul class="links">
                    <li><a href="https://forms.gle/JaQHWfzcVD4Lnaf18" class="ltext" target="_blank" rel="noopener noreferrer">Submit your ICF here <i class="bx bx-link-external"></i></a></li>
                </ul>  <br>
    
    If you have submitted your ICF already, you can start using the webapp by clicking the button below. When you are ready, you can answer the survey by clicking the User Survey icon (<i class="bx bx-list-check"></i>) on the sidebar.</p><br>

    </h1>
    ';
    echo "<form action='includes/update_status.inc.php' method='post'>
            <button class='btn-login' name='submit' type='submit' value='$uid+|+survey_pending'> I have signed and submitted my ICF</button>
        </form><br>"
        ;
}
