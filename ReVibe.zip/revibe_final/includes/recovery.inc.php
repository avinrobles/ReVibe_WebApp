<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = strtolower($_POST["email"]);
    $selector = bin2hex(random_bytes(8));
    $token = random_bytes(32);
    $url = "www.revibe.fun/recover-password.php?selector=" . $selector . "&validator=" . bin2hex($token);
    $expires = time() + 600;
    $errors = [];
    
    if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])) {
        $scKey = "6LfTpYUqAAAAAE5mKugXKjTlj59iyCvFe6TRVCxA";
        $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$scKey.'&response='.$_POST['g-recaptcha-response']);
        $resp = json_decode($verifyResponse);
        if($resp->success) {
            $verified = true;
        } else $errors['err-captcha'] = 'Error in verifying reCaptcha!';
    } else $errors['no-captcha'] = 'Error in reCaptcha!';


    try {
        require_once 'dbh.inc.php';
        require_once 'recovery_model.inc.php';
        require_once 'recovery_contr.inc.php';

        // ERROR HANDLERS

        if (is_empty_input($email)) {
            $errors["empty_input"] = "Empty Inputs!";
        }

        if (is_email_invalid($email)) {
            $errors["invalid_email"] = "Invalid Email!";
        }


        if (!is_email_registered($pdo, $email)) {
            $errors["email_not_registered"] = "Email not Registered!";
        }

        require_once 'config_session.inc.php';

        if ($errors) {
            $_SESSION["errors_recovery"] = $errors;
            $pdo = null;
            $stmt = null;

            header("location: ../recovery.php");
            die();
        }

        delete_active_token($pdo, $email);
        new_active_token($pdo, $email, $selector, $token, $expires);
        send_email($url, $email);


        //always have this at the end
        header("Location: ../recovery.php?reset=success");
        $pdo = null;
        $stmt = null;
        die();

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("location: ../recovery.php");
    die();
}