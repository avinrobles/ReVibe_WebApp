<?php

declare(strict_types=1);

// all functions between db and webpage

function is_empty_input(string $email) {
    
    if (empty($email)) {
        return true;       
    }
    else {
        return false;
    }

}

function is_email_invalid(string $email) {
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return true;       
    } else {
        return false;
    }

}

function is_email_registered(object $pdo, string $email) {

    if (get_email($pdo, $email)) {
        return true;       
    } else {
        return false;
    }

}

function send_email(string $url, string $email) {
    $subject = 'ReVibe.fun Password Reset';
    $message = '<p>We have received a password reset request. Please proceed to the link below to reset your password. If you did not make this request, please ignore this message.</p><br>';
    $message .= '<a href="' . $url . '">' . $url . '</a>';

    $headers = "From: support <support@revibe.fun>\r\n";
    $headers .= "Reply-To: support@revibe.fun\r\n";
    $headers .= "Content-type: text/html\r\n";

    mail($email, $subject, $message, $headers);
}

//Resetting Password
function is_empty(string $pwd, string $cpwd) {
    
    if (empty($pwd) || empty($cpwd)) {
        return true;       
    }
    else {
        return false;
    }

}

function are_passwords_different(string $pwd, string $cpwd) {
    
    if ($pwd !== $cpwd) {
        return true;       
    } else {
        return false;
    }

}