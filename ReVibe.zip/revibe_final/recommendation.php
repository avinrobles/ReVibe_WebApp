<?php
require_once 'includes/config_session.inc.php';

if (!isset($_SESSION["user_id"])) {
    header('Location: index.php');
}

if (isset($_GET['r'])) {
    require_once 'includes/show_reco.inc.php';
}

$notif = 1;

if ($list) {
    $createdAt = $list['created_at'];
    $recoType = $list['reco_type'];
    $inputString = $list['input_text'];
    $imLoc = $list['input_image_loc'];
    $subtype = $list['subtype'];
    $predEmo = explode(' - ', $subtype)[0];
    $wanted = explode(' - ', $subtype)[1];
    //echo $predEmo;
    $isCorrectPred = $list['is_correct_prediction'];
    $replaces = $list['replacement_to'];
    $tracks = json_decode($list['recos_json'], true);
    //var_dump($tracks);
    $ucReco = ucwords($recoType);
    $ucSub = ucwords("$predEmo - $wanted");
} else {
    $notif = 1;
}

require_once 'includes/recos_view.inc.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recommendation | ReVibe</title>
    <link rel="stylesheet" href="css/reset.css">
    <?php require 'parts/css.parts.php';?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script>
        $(document).ready(function () {

            $('#validate_pred').submit(function() {
                event.preventDefault();
                uid = <?php  echo $_SESSION["user_id"]; ?>;
                createdat = <?php  echo $createdAt; ?>;
                predemo = '<?php  echo $predEmo; ?>';
                subtype = '<?php  echo $subtype; ?>';
                correctemo = $('#correct_emo').val();
                wantnew = $('#wantnew').val()
                submit = $('#submit').val();
                $('.response').load('includes/new_reco.inc.php', {
                    uid: uid,
                    createdat: createdat,
                    predemo: predemo,
                    subtype: subtype,
                    correctemo: correctemo,
                    wantnew: wantnew
                })
            });

            $('#correct_emo').change(function() {
                let _this = $(this);
                if (_this.val() == '<?php echo $predEmo; ?>') {
                    $('#disp-if-wrong').fadeOut();
                } else {
                    $('#disp-if-wrong').fadeIn();
                }
            })

            $('.play_request').submit(function() {
                event.preventDefault();
                let form = $(this);
                val = form.find('#to-play').val();
                //console.log(val);
                $('.player').load('includes/play.inc.php', {
                    val: val
                })
            });
            
        });
    </script>

</head>
<body class="home-gradient">
    <div class="grid-main">
        <div class="grid-container header">
            <div class="title-header">
                <p class="bold">Music Recommendation</p>
            </div>
        </div>
        <div class="grid-container main-content main">
            <div class="grid-box-static x-split">
                <div class='half1'>
                    <div class="flex">
                    <a href="history.php"><button class="back-btn"><i class='bx bxs-left-arrow-circle'></i></button></a>
                    <p class="big bold">
                        <?php
                      if ($recoType == 'emotion') {
                        echo " You're $predEmo, here's some '$wanted' songs for you! <br>This was created on "; display_time($createdAt); 
                      } elseif ($recoType == 'weather')  {
                        echo "Here's some '$wanted' songs for the '$predEmo' $recoType!<br>This was created on "; display_time($createdAt); 
                      } elseif ($recoType == 'sleep')   {
                        echo "Here's some songs for sleeping!<br>This was created on "; display_time($createdAt); 
                      } else  {
                        echo "Here's some songs for stress relief!<br>This was created on "; display_time($createdAt); 
                      }
                    ?>
                    </p><br>
                    </div>
                    <p>These recommendations are based on your music preferences. You can get different song recommendations if you change your preferences!</p>
                    <p>*Due to limitation in API calls, sometimes the song may not play in the webapp. External links are provided so you can play them there.</p>
                    <div id="prompts">
                        <form action='includes/new_reco.inc.php' method='post' id='validate_pred'>
                            <hr><br>
                            To validate our prediction, please select your expected emotion: 
                            <select name='correct_emo' id='correct_emo' class='selection' required>
                                <option value='' disabled selected hidden>-select emotion-</option>
                                <option value='happy'>Happy</option>
                                <option value='sad'>Sad</option>
                                <option value='angry'>Angry</option>
                                <option value='fear'>Fear</option>
                                <option value='surprise'>Surprise</option>
                            </select><br>
                            <div id='disp-if-wrong' style='display: none;'>
                                Looks like our prediction is wrong. <br>Do you want a new set of songs for your selected emotion?
                                <select name='wantnew' id='wantnew' class='selection'>
                                <option value='no' selected>No</option>
                                <option value='yes'>Yes</option>
                            </select>
                            </div><br>
                            <div class="response"></div>
                            <div class='center'><button type='submit' class='btn-login' id='submit' >Submit</button></div>
                            <br>
                            <hr>
                        </form>
                        
                    </div>
                        <?php 
                            if($list && $tracks) {
                                display_list($tracks);
                            } elseif ($list && !$tracks){
                                // echo " <br> Hello, this is Ma2l, one of the researchers who developed this web app. Unfortunately, one of the vital API endpoints this web app uses is now deprecated as of November 28, 2024. This means that we can't provide new recommendations anymore, I want to sincerely apologize for this sudden development.
                                // Fortunately all recommendations made prior to the stated date above are still up and available, you can access them in 'Recommendation History'. We are still accepting respondents for the survey to those who have existing recommendations. To those who does not have existing ones, you don't
                                // ";
                                echo "<br> Sorry, there was an error in the response on one of our api. Please try a new recommendation.";
                            } else {
                                display_default();
                            }
                        ?>
                    <br>
                </div>
                <div class='half2 player center'>
                <p class="big bold">No songs playing...</p>
                </div>
            </div>
        </div>
    </div>
    <?php require 'parts/sidebar.parts.php';?>
</body>
<script>
    let burger = document.querySelector("#burger");
    let sidebar = document.querySelector('.sidebar');
    burger.onclick = function() {
        sidebar.classList.toggle('active');
    }

    //let type = '<php echo $recoType >';  type != 'emotion' && //  valStatus != 'pending'
    let valStatus =  '<?php echo $isCorrectPred ?>';
            if (valStatus != 'pending') {
                console.log('apples');
                document.getElementById('prompts').style.display = 'none';
            } else console.log('bananas');

</script>
</html>