<?php
require_once 'includes/config_session.inc.php';
require_once 'includes/recovery_view.inc.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | ReVibe</title>
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <div class="row">
        <div class="col-6 svg-container">
            <img src="webimages/REVIBE.svg">
        </div>
        <div class="col-6">
            <div class="container">
                
                <?php 
                if (isset($_GET['selector']) && isset($_GET['validator'])) {
                    $selector = $_GET["selector"];
                    $validator = $_GET["validator"];
                    show_reset_form($selector, $validator);
                } else {
                    echo '<div>';
                    echo 'Something went wrong. Returning you to the Login Page.';
                    echo '</div>';
                    header('refresh: 5; index.php');
                }
                check_recovery_errors();
                 ?> 
            </div>
        </div>
    </div>
    <script src="js/script.js"></script>
</body>
</html>