document.addEventListener('DOMContentLoaded', () => {
    
    // Add smooth appearance animation to form
    document.querySelector('.container').style.opacity = '0';
    setTimeout(() => {
        document.querySelector('.container').style.transition = 'opacity 0.5s ease-in-out';
        document.querySelector('.container').style.opacity = '1';
    }, 100);
});

function shakeForm() {
    const form = document.querySelector('.form');
    form.classList.add('shake');
    setTimeout(() => {
        form.classList.remove('shake');
    }, 820);
}